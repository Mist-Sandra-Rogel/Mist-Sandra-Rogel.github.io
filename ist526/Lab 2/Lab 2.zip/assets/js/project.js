if(!window.cp)window.cp = function(str){return document.getElementById(str)};cp.CPProjInit = function(){if(cp && cp.model && cp.model.data) return; cp.model = {}; cp.poolResources = {}; cp.D = cp.model.data = {
pref:{
acc:1,
rkt:1,
hsr:0,
atp:false
},
si8592:{
name:'Image_2',
type:1268,
from:1,
to:639,
rp:0,
rpa:0,
mdi:'si8592c',
tag:'container-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":520,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIXED_HEIGHT","padding":{"left":0,"right":5,"top":0,"bottom":0},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":1.18}',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si8586',
t:1268
}
]
,
containerType:'image',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":520,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIXED_HEIGHT","padding":{"left":0,"right":5,"top":0,"bottom":0},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":1.18}',
option:'SINGLE_IMAGE_OPTION_ROW_C1',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si8592c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:8592,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8592',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si8586:{
name:'Image_Group_2',
type:1268,
from:1,
to:639,
rp:0,
rpa:0,
mdi:'si8586c',
tag:'container-image-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-buttons":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":30,"bottom":30,"left":30,"right":30},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":3},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridTemplateRows":"minmax(10px,auto)","gridGap":"0 10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}}}',
parentGroup:'si8592',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si8501',
t:15
}
,{
n:'si8529',
t:1268
}
]
,
containerType:'image-single-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-buttons":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":30,"bottom":30,"left":30,"right":30},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":3},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridTemplateRows":"minmax(10px,auto)","gridGap":"0 10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si8592',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si8586c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:8586,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8586',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si8501:{
name:'AdobeStock_259463465',
type:15,
from:1,
to:639,
rp:0,
rpa:0,
mdi:'si8501c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.3,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"0 50% 50% 0","overflow":"hidden"},"tablet":{"borderRadius":"0"},"mobile":{"borderRadius":"0"}}}',
parentGroup:'si8586',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:7360,
irh:4912,
w:7360,
h:4912,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8501]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8501c:{
b:[0,0,7360,4912],
fh:false,
fw:false,
uid:8501,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'171.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'171.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'171.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/08657.jpeg',
dn:'si8501',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,7361,4913],
vb:[-1,-1,7361,4913]
},
si8529:{
name:'Image_Group_Text_2',
type:1268,
from:1,
to:639,
rp:0,
rpa:0,
mdi:'si8529c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"30px"},"tablet":{"paddingLeft":"0px"},"mobile":{"paddingLeft":"0px"}}}',
parentGroup:'si8586',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si8513',
t:1250
}
,{
n:'si8523',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"30px"},"tablet":{"paddingLeft":"0px"},"mobile":{"paddingLeft":"0px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si8586',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si8529c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:8529,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8529',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si8513:{
name:'Text_3',
type:1250,
from:1,
to:639,
rp:0,
rpa:0,
mdi:'si8513c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"align-items":"start"},"tablet":{},"mobile":{}}}',
parentGroup:'si8529',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dp5k8","text":"Create a Gmail Signature ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":25,"style":"hlnk:"},{"offset":0,"length":25,"style":"hlnkt:wp"},{"offset":0,"length":25,"style":"textOutlineEnable:false"},{"offset":0,"length":25,"style":"opacity:1"},{"offset":0,"length":25,"style":"hlnke:true"},{"offset":0,"length":25,"style":"backgroundColor:unset"},{"offset":0,"length":25,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":25,"style":"textHighlightEnable:false"},{"offset":0,"length":25,"style":"textShadowEnable:false"},{"offset":0,"length":25,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8513]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8513c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:8513,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8513',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si8523:{
name:'Text_4',
type:1250,
from:1,
to:639,
rp:0,
rpa:0,
mdi:'si8523c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"marginTop":"50px"},"tablet":{"marginTop":"0px"},"mobile":{"marginTop":"0px"}}}',
parentGroup:'si8529',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"a2ham","text":"Sandra Rogel ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":13,"style":"hlnk:"},{"offset":0,"length":13,"style":"hlnkt:wp"},{"offset":0,"length":13,"style":"textOutlineEnable:false"},{"offset":0,"length":13,"style":"opacity:1"},{"offset":0,"length":13,"style":"hlnke:true"},{"offset":0,"length":13,"style":"backgroundColor:unset"},{"offset":0,"length":13,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":13,"style":"textHighlightEnable:false"},{"offset":0,"length":13,"style":"textShadowEnable:false"},{"offset":0,"length":13,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8523]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8523c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:8523,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8523',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si8593:{
name:'Block_Button_1',
type:1268,
from:121,
to:639,
rp:0,
rpa:0,
mdi:'si8593c',
tag:'container-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:4,
sid:17.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":1,"bottom":1,"right":10,"left":43},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si8601',
t:1268
}
]
,
containerType:'button',
widgetProps:'{"padding":{"top":1,"bottom":1,"right":10,"left":43},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'DEFAULT_BUTTON_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si8593c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:8593,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8593',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si8601:{
name:'Block_Button_Group_1',
type:1268,
from:121,
to:639,
rp:0,
rpa:0,
mdi:'si8601c',
tag:'container-button-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:4,
sid:17.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"padding":{"top":20,"bottom":20,"left":20,"right":20},"groupedItemsVisibility":{"slide-item-buttons":1},"visibilityInfo":{"slide-item-buttons":true,"card":false},"alignment":{"slide-item-buttons":"LEFT"},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{},"tablet":{},"mobile":{}}}}',
parentGroup:'si8593',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si8609',
t:29
}
,{
n:'si8625',
t:29
}
,{
n:'si8641',
t:29
}
]
,
containerType:'button-card',
widgetProps:'{"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"padding":{"top":20,"bottom":20,"left":20,"right":20},"groupedItemsVisibility":{"slide-item-buttons":1},"visibilityInfo":{"slide-item-buttons":true,"card":false},"alignment":{"slide-item-buttons":"LEFT"},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si8593',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si8601c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:8601,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8601',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si8609:{
name:'Button_7',
type:29,
from:121,
to:639,
rp:0,
rpa:0,
mdi:'si8609c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:4,
sid:17.3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"885k8","text":"Start","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"textTransform:uppercase"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"fontWeight:bold"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"letterSpacing:12%"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"fontType:400"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"tablet-fontSize:16"},{"offset":0,"length":5,"style":"fontStyle:italic"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"color:#FFFFFF"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"lineHeight:125%"},{"offset":0,"length":5,"style":"fontFamily:Volkhov"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"overridden:true"},{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"desktop-fontSize:96"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"color":"#66C4D9FF"},"shadow":{"enabled":true,"shadowX":-3,"shadowY":3,"shadowBlur":6,"shadowType":2},"stroke":{"color":"#66C4D9FF"}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1eoou","text":"Start","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"fontFamily:Volkhov"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"overridden:true"},{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"desktop-fontSize:96"},{"offset":0,"length":5,"style":"textTransform:uppercase"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"fontWeight:bold"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"letterSpacing:12%"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"fontType:400"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"tablet-fontSize:16"},{"offset":0,"length":5,"style":"fontStyle:italic"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"color:#FFFFFF"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"lineHeight:125%"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{},"shadow":{"enabled":true,"shadowX":-3,"shadowY":3,"shadowBlur":6,"shadowType":2},"stroke":{}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","iconProps":{"srcPath":"08412.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1ldog","text":"Start","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"overridden:true"},{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"desktop-fontSize:96"},{"offset":0,"length":5,"style":"textTransform:uppercase"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"fontWeight:bold"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"letterSpacing:12%"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"fontType:400"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"tablet-fontSize:16"},{"offset":0,"length":5,"style":"fontStyle:italic"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"color:#FFFFFF"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"lineHeight:125%"},{"offset":0,"length":5,"style":"fontFamily:Volkhov"},{"offset":0,"length":5,"style":"textShadowBlur:0px"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{},"shadow":{"enabled":true,"shadowX":-3,"shadowY":3,"shadowBlur":6,"shadowType":2},"stroke":{}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8mtte","text":"Start","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"lineHeight:125%"},{"offset":0,"length":5,"style":"fontFamily:Volkhov"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"overridden:true"},{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"desktop-fontSize:96"},{"offset":0,"length":5,"style":"textTransform:uppercase"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"fontWeight:bold"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"letterSpacing:12%"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"fontType:400"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"tablet-fontSize:16"},{"offset":0,"length":5,"style":"fontStyle:italic"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"color:#FFFFFF"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{},"shadow":{"shadowX":-3,"shadowY":3,"shadowBlur":6,"shadowType":2},"stroke":{}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9bjns","text":"Start","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"desktop-fontSize:96"},{"offset":0,"length":5,"style":"textTransform:uppercase"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"fontWeight:bold"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"letterSpacing:12%"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"fontType:400"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"tablet-fontSize:16"},{"offset":0,"length":5,"style":"fontStyle:italic"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"color:#666666"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"lineHeight:125%"},{"offset":0,"length":5,"style":"fontFamily:Volkhov"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"overridden:true"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{},"shadow":{"enabled":true,"shadowX":-3,"shadowY":3,"shadowBlur":6,"shadowType":2},"stroke":{}}}}',
parentGroup:'si8601',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8609]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8609c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:8609,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8609',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si8625:{
name:'Button_8',
type:29,
from:121,
to:639,
rp:0,
rpa:0,
mdi:'si8625c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:4,
sid:17.3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"08412.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ed4gu","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"30i4h","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"88j9q","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a22b0","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"436la","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si8601',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8625]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8625c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:8625,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8625',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si8641:{
name:'Button_9',
type:29,
from:121,
to:639,
rp:0,
rpa:0,
mdi:'si8641c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:4,
sid:17.3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"08412.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a6h1i","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ek7","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7kajd","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"e0035","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"e9oso","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si8601',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[8641]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si8641c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:8641,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si8641',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide388:{
lb:'Blank 1',
id:388,
from:1,
to:639,
iols:0,
i360qs:false,
sdu:21.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide388c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si8592',
t:1268
}
,{
n:'si8593',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide388c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:388,
dn:'Slide388',
visible:'1'
},
si9987:{
name:'Simulation_1',
type:1268,
from:640,
to:1074,
rp:0,
rpa:0,
mdi:'si9987c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide9961',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si9979',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si9987c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:9987,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si9987',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si9979:{
name:'Simulation_non_responsive_1',
type:1268,
from:640,
to:1074,
rp:0,
rpa:0,
mdi:'si9979c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si9987',
retainState:false,
immo:false,
apsn:'Slide9961',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si9998',
t:1269
}
,{
n:'si10018',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si9987',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si9979c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:9979,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si9979',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:9995,
tsp:50,
ip:'dr/09995.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si9998:{
name:'Click_box_1',
type:1269,
from:640,
to:1074,
rp:0,
rpa:0,
mdi:'si9998c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.5,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":135,"left":1119,"width":31,"height":30},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si9979',
retainState:false,
immo:false,
apsn:'Slide9961',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(10071);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:14.46,
lcapid:'si10018',
si:[{
n:'si10008',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[9998]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si9998c:{
b:[1119,135,1150,165],
fh:false,
fw:false,
uid:9998,
iso:false,
css:{
360:{
l:'115.123%',
t:'22.204%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'115.123%',
lhID:-1,
lvEID:0,
lvV:'22.204%',
lvID:-1,
w:'3.189%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'115.123%',
t:'22.204%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'115.123%',
lhID:-1,
lvEID:0,
lvV:'22.204%',
lvID:-1,
w:'3.189%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'115.123%',
t:'22.204%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'115.123%',
lhID:-1,
lvEID:0,
lvV:'22.204%',
lvID:-1,
w:'3.189%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si9998',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1119,135,1150,165],
vb:[1119,135,1150,165]
},
si10008:{
name:'Shape_1',
type:612,
from:640,
to:1074,
rp:0,
rpa:0,
mdi:'si10008c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide9961',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10008]
}
]
,
stis:0,
bstiid:9998,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si9998',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si10008c:{
b:[0,0,31,30],
fh:false,
fw:false,
uid:10008,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.189%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.189%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.189%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10008',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,33,32],
vb:[-2,-2,33,32]
},
si10018:{
name:'Rectangle_1',
type:612,
from:640,
to:1074,
rp:0,
rpa:0,
mdi:'si10018c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.5,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":195,"left":804,"width":300,"height":"auto"}}',
parentGroup:'si9979',
retainState:false,
immo:false,
apsn:'Slide9961',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:10029,
stt:0,
dsr:'Default_State',
stsi:[10018]
}
,{
stn:10041,
stt:102,
dsr:'Failure',
stsi:[10042]
}
,{
stn:10052,
stt:103,
dsr:'Hint',
stsi:[10053]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si10018','si10031','si10042','si10053'],
isDD:false
},
si10018c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10018,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10018',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10031:{
name:'',
type:612,
from:640,
to:1074,
rp:0,
rpa:0,
mdi:'si10031c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":195,"left":804,"width":300,"height":"auto"}}',
parentGroup:'si9979',
retainState:false,
immo:false,
apsn:'Slide9961',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10018',
stl:[{
stn:'Normal',
stt:0,
stsi:[10031]
}
]
,
stis:0,
bstiid:10018,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10018,
isDD:false
},
si10031c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10031,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10031',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10042:{
name:'',
type:612,
from:640,
to:1074,
rp:0,
rpa:0,
mdi:'si10042c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":195,"left":804,"width":300,"height":"auto"}}',
parentGroup:'si9979',
retainState:false,
immo:false,
apsn:'Slide9961',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10018',
stl:[{
stn:'Normal',
stt:0,
stsi:[10042]
}
]
,
stis:0,
bstiid:10018,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10018,
isDD:false
},
si10042c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10042,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10042',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10053:{
name:'',
type:612,
from:640,
to:1074,
rp:0,
rpa:0,
mdi:'si10053c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:14.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":195,"left":804,"width":300,"height":"auto"}}',
parentGroup:'si9979',
retainState:false,
immo:false,
apsn:'Slide9961',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10018',
stl:[{
stn:'Normal',
stt:0,
stsi:[10053]
}
]
,
stis:0,
bstiid:10018,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10018,
isDD:false
},
si10053c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10053,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10053',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide9961:{
lb:'Simulation slide 1',
id:9961,
from:640,
to:1074,
iols:0,
i360qs:false,
sdu:14.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide9961c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si9987',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
10071:{
ts:''
}

}

},
Slide9961c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:9961,
dn:'Slide9961',
visible:'1'
},
si10104:{
name:'Simulation_2',
type:1268,
from:1075,
to:1074,
rp:0,
rpa:0,
mdi:'si10104c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide10078',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10096',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10104c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10104,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10104',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10096:{
name:'Simulation_non_responsive_2',
type:1268,
from:1075,
to:1074,
rp:0,
rpa:0,
mdi:'si10096c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si10104',
retainState:false,
immo:false,
apsn:'Slide10078',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si10104',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10096c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10096,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10096',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:10112,
tsp:50,
ip:'dr/010112.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide10078:{
lb:'Simulation slide 2',
id:10078,
from:1075,
to:1117,
iols:0,
i360qs:false,
sdu:1.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10078c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10104',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide10078c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10078,
dn:'Slide10078',
visible:'1'
},
si10141:{
name:'Simulation_3',
type:1268,
from:1118,
to:1521,
rp:0,
rpa:0,
mdi:'si10141c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide10115',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10133',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10141c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10141,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10141',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10133:{
name:'Simulation_non_responsive_3',
type:1268,
from:1118,
to:1521,
rp:0,
rpa:0,
mdi:'si10133c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si10141',
retainState:false,
immo:false,
apsn:'Slide10115',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10152',
t:1269
}
,{
n:'si10172',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si10141',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10133c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10133,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10133',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:10149,
tsp:50,
ip:'dr/010149.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10152:{
name:'Click_box_2',
type:1269,
from:1118,
to:1521,
rp:0,
rpa:0,
mdi:'si10152c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.4,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":255,"left":842,"width":360,"height":45},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si10133',
retainState:false,
immo:false,
apsn:'Slide10115',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(10225);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:13.439,
lcapid:'si10172',
si:[{
n:'si10162',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10152]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si10152c:{
b:[842,255,1202,300],
fh:false,
fw:false,
uid:10152,
iso:false,
css:{
360:{
l:'86.626%',
t:'41.941%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'86.626%',
lhID:-1,
lvEID:0,
lvV:'41.941%',
lvID:-1,
w:'37.037%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'86.626%',
t:'41.941%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'86.626%',
lhID:-1,
lvEID:0,
lvV:'41.941%',
lvID:-1,
w:'37.037%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'86.626%',
t:'41.941%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'86.626%',
lhID:-1,
lvEID:0,
lvV:'41.941%',
lvID:-1,
w:'37.037%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10152',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[842,255,1202,300],
vb:[842,255,1202,300]
},
si10162:{
name:'Shape_2',
type:612,
from:1118,
to:1521,
rp:0,
rpa:0,
mdi:'si10162c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide10115',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10162]
}
]
,
stis:0,
bstiid:10152,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si10152',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si10162c:{
b:[0,0,360,45],
fh:false,
fw:false,
uid:10162,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'37.037%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'37.037%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'37.037%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10162',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,362,47],
vb:[-2,-2,362,47]
},
si10172:{
name:'Rectangle_2',
type:612,
from:1118,
to:1521,
rp:0,
rpa:0,
mdi:'si10172c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.4,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":315,"left":857,"width":300,"height":"auto"}}',
parentGroup:'si10133',
retainState:false,
immo:false,
apsn:'Slide10115',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:10183,
stt:0,
dsr:'Default_State',
stsi:[10172]
}
,{
stn:10195,
stt:102,
dsr:'Failure',
stsi:[10196]
}
,{
stn:10206,
stt:103,
dsr:'Hint',
stsi:[10207]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si10172','si10185','si10196','si10207'],
isDD:false
},
si10172c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10172,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10172',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10185:{
name:'',
type:612,
from:1118,
to:1521,
rp:0,
rpa:0,
mdi:'si10185c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":315,"left":857,"width":300,"height":"auto"}}',
parentGroup:'si10133',
retainState:false,
immo:false,
apsn:'Slide10115',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10172',
stl:[{
stn:'Normal',
stt:0,
stsi:[10185]
}
]
,
stis:0,
bstiid:10172,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10172,
isDD:false
},
si10185c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10185,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10185',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10196:{
name:'',
type:612,
from:1118,
to:1521,
rp:0,
rpa:0,
mdi:'si10196c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":315,"left":857,"width":300,"height":"auto"}}',
parentGroup:'si10133',
retainState:false,
immo:false,
apsn:'Slide10115',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10172',
stl:[{
stn:'Normal',
stt:0,
stsi:[10196]
}
]
,
stis:0,
bstiid:10172,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10172,
isDD:false
},
si10196c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10196,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10196',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10207:{
name:'',
type:612,
from:1118,
to:1521,
rp:0,
rpa:0,
mdi:'si10207c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":315,"left":857,"width":300,"height":"auto"}}',
parentGroup:'si10133',
retainState:false,
immo:false,
apsn:'Slide10115',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10172',
stl:[{
stn:'Normal',
stt:0,
stsi:[10207]
}
]
,
stis:0,
bstiid:10172,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10172,
isDD:false
},
si10207c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10207,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10207',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide10115:{
lb:'Simulation slide 3',
id:10115,
from:1118,
to:1521,
iols:0,
i360qs:false,
sdu:13.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10115c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10141',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
10225:{
ts:''
}

}

},
Slide10115c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10115,
dn:'Slide10115',
visible:'1'
},
si10258:{
name:'Simulation_4',
type:1268,
from:1522,
to:1521,
rp:0,
rpa:0,
mdi:'si10258c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide10232',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10250',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10258c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10258,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10258',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10250:{
name:'Simulation_non_responsive_4',
type:1268,
from:1522,
to:1521,
rp:0,
rpa:0,
mdi:'si10250c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si10258',
retainState:false,
immo:false,
apsn:'Slide10232',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si10258',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10250c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10250,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10250',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:10266,
tsp:50,
ip:'dr/010266.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide10232:{
lb:'Simulation slide 4',
id:10232,
from:1522,
to:1688,
iols:0,
i360qs:false,
sdu:5.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10232c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10258',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide10232c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10232,
dn:'Slide10232',
visible:'1'
},
si10287:{
name:'Video_1',
type:1268,
from:1689,
to:1700,
rp:0,
rpa:0,
mdi:'si10287c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide10269',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10306',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10287c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10287,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10287',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10306:{
name:'SlideVideo_27',
type:365,
from:1689,
to:1700,
rp:0,
rpa:0,
mdi:'si10306c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.4,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si10287',
retainState:false,
immo:false,
apsn:'Slide10269',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si10306c:{
b:[-161,-206,1133,814],
fh:false,
fw:false,
uid:10306,
iso:false,
css:{
360:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10306',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/010302.png',
mp4:'vr/Vi10295.mp4',
vsf:0,
vst:0.4,
o:100,
vbwr:[-162,-207,1134,815],
vb:[-162,-207,1134,815]
},
Slide10269:{
lb:'Simulation slide 5',
id:10269,
from:1689,
to:1700,
iols:0,
i360qs:false,
sdu:0.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10269c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10287',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide10269c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10269,
dn:'Slide10269',
visible:'1'
},
si10339:{
name:'Simulation_5',
type:1268,
from:1701,
to:1700,
rp:0,
rpa:0,
mdi:'si10339c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide10313',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10331',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10339c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10339,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10339',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10331:{
name:'Simulation_non_responsive_5',
type:1268,
from:1701,
to:1700,
rp:0,
rpa:0,
mdi:'si10331c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si10339',
retainState:false,
immo:false,
apsn:'Slide10313',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si10339',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10331c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10331,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10331',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:10347,
tsp:50,
ip:'dr/010347.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide10313:{
lb:'Simulation slide 6',
id:10313,
from:1701,
to:1709,
iols:0,
i360qs:false,
sdu:0.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10313c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10339',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide10313c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10313,
dn:'Slide10313',
visible:'1'
},
si10368:{
name:'Video_2',
type:1268,
from:1710,
to:1742,
rp:0,
rpa:0,
mdi:'si10368c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide10350',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10387',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10368c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10368,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10368',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10387:{
name:'SlideVideo_28',
type:365,
from:1710,
to:1742,
rp:0,
rpa:0,
mdi:'si10387c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.1,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si10368',
retainState:false,
immo:false,
apsn:'Slide10350',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si10387c:{
b:[-161,-206,1133,814],
fh:false,
fw:false,
uid:10387,
iso:false,
css:{
360:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10387',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/010383.png',
mp4:'vr/Vi10376.mp4',
vsf:0,
vst:1.1,
o:100,
vbwr:[-162,-207,1134,815],
vb:[-162,-207,1134,815]
},
Slide10350:{
lb:'Simulation slide 7',
id:10350,
from:1710,
to:1742,
iols:0,
i360qs:false,
sdu:1.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10350c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10368',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide10350c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10350,
dn:'Slide10350',
visible:'1'
},
si10420:{
name:'Simulation_6',
type:1268,
from:1743,
to:2075,
rp:0,
rpa:0,
mdi:'si10420c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:11.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide10394',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10412',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10420c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10420,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10420',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10412:{
name:'Simulation_non_responsive_6',
type:1268,
from:1743,
to:2075,
rp:0,
rpa:0,
mdi:'si10412c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:11.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si10420',
retainState:false,
immo:false,
apsn:'Slide10394',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10431',
t:1269
}
,{
n:'si10451',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si10420',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10412c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10412,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10412',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:10428,
tsp:50,
ip:'dr/010428.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10431:{
name:'Click_box_3',
type:1269,
from:1743,
to:2075,
rp:0,
rpa:0,
mdi:'si10431c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:11.1,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":764,"left":486,"width":170,"height":45},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si10412',
retainState:false,
immo:false,
apsn:'Slide10394',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(10504);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:11.063,
lcapid:'si10451',
si:[{
n:'si10441',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10431]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si10431c:{
b:[486,764,656,809],
fh:false,
fw:false,
uid:10431,
iso:false,
css:{
360:{
l:'50.000%',
t:'125.658%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.000%',
lhID:-1,
lvEID:0,
lvV:'125.658%',
lvID:-1,
w:'17.490%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'50.000%',
t:'125.658%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.000%',
lhID:-1,
lvEID:0,
lvV:'125.658%',
lvID:-1,
w:'17.490%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'50.000%',
t:'125.658%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.000%',
lhID:-1,
lvEID:0,
lvV:'125.658%',
lvID:-1,
w:'17.490%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10431',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[486,764,656,809],
vb:[486,764,656,809]
},
si10441:{
name:'Shape_3',
type:612,
from:1743,
to:2075,
rp:0,
rpa:0,
mdi:'si10441c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:11.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide10394',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10441]
}
]
,
stis:0,
bstiid:10431,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si10431',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si10441c:{
b:[0,0,170,45],
fh:false,
fw:false,
uid:10441,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'17.490%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'17.490%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'17.490%',
h:'7.401%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10441',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,172,47],
vb:[-2,-2,172,47]
},
si10451:{
name:'Rectangle_3',
type:612,
from:1743,
to:2075,
rp:0,
rpa:0,
mdi:'si10451c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:11.1,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":824,"left":501,"width":300,"height":"auto"}}',
parentGroup:'si10412',
retainState:false,
immo:false,
apsn:'Slide10394',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:10462,
stt:0,
dsr:'Default_State',
stsi:[10451]
}
,{
stn:10474,
stt:102,
dsr:'Failure',
stsi:[10475]
}
,{
stn:10485,
stt:103,
dsr:'Hint',
stsi:[10486]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si10451','si10464','si10475','si10486'],
isDD:false
},
si10451c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10451,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10451',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10464:{
name:'',
type:612,
from:1743,
to:2075,
rp:0,
rpa:0,
mdi:'si10464c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:11.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":824,"left":501,"width":300,"height":"auto"}}',
parentGroup:'si10412',
retainState:false,
immo:false,
apsn:'Slide10394',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10451',
stl:[{
stn:'Normal',
stt:0,
stsi:[10464]
}
]
,
stis:0,
bstiid:10451,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10451,
isDD:false
},
si10464c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10464,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10464',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10475:{
name:'',
type:612,
from:1743,
to:2075,
rp:0,
rpa:0,
mdi:'si10475c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:11.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":824,"left":501,"width":300,"height":"auto"}}',
parentGroup:'si10412',
retainState:false,
immo:false,
apsn:'Slide10394',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10451',
stl:[{
stn:'Normal',
stt:0,
stsi:[10475]
}
]
,
stis:0,
bstiid:10451,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10451,
isDD:false
},
si10475c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10475,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10475',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10486:{
name:'',
type:612,
from:1743,
to:2075,
rp:0,
rpa:0,
mdi:'si10486c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:11.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":824,"left":501,"width":300,"height":"auto"}}',
parentGroup:'si10412',
retainState:false,
immo:false,
apsn:'Slide10394',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10451',
stl:[{
stn:'Normal',
stt:0,
stsi:[10486]
}
]
,
stis:0,
bstiid:10451,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10451,
isDD:false
},
si10486c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10486,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10486',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide10394:{
lb:'Simulation slide 8',
id:10394,
from:1743,
to:2075,
iols:0,
i360qs:false,
sdu:11.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10394c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10420',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
10504:{
ts:''
}

}

},
Slide10394c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10394,
dn:'Slide10394',
visible:'1'
},
si10537:{
name:'Simulation_7',
type:1268,
from:2076,
to:2383,
rp:0,
rpa:0,
mdi:'si10537c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide10511',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10529',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10537c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10537,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10537',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10529:{
name:'Simulation_non_responsive_7',
type:1268,
from:2076,
to:2383,
rp:0,
rpa:0,
mdi:'si10529c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si10537',
retainState:false,
immo:false,
apsn:'Slide10511',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10548',
t:1269
}
,{
n:'si10568',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si10537',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10529c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10529,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10529',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:10545,
tsp:50,
ip:'dr/010545.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10548:{
name:'Click_box_4',
type:1269,
from:2076,
to:2383,
rp:0,
rpa:0,
mdi:'si10548c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":641,"left":819,"width":57,"height":23},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si10529',
retainState:false,
immo:false,
apsn:'Slide10511',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(10621);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:10.237,
lcapid:'si10568',
si:[{
n:'si10558',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10548]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si10548c:{
b:[819,641,876,664],
fh:false,
fw:false,
uid:10548,
iso:false,
css:{
360:{
l:'84.259%',
t:'105.428%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'84.259%',
lhID:-1,
lvEID:0,
lvV:'105.428%',
lvID:-1,
w:'5.864%',
h:'3.783%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'84.259%',
t:'105.428%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'84.259%',
lhID:-1,
lvEID:0,
lvV:'105.428%',
lvID:-1,
w:'5.864%',
h:'3.783%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'84.259%',
t:'105.428%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'84.259%',
lhID:-1,
lvEID:0,
lvV:'105.428%',
lvID:-1,
w:'5.864%',
h:'3.783%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10548',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[819,641,876,664],
vb:[819,641,876,664]
},
si10558:{
name:'Shape_4',
type:612,
from:2076,
to:2383,
rp:0,
rpa:0,
mdi:'si10558c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide10511',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10558]
}
]
,
stis:0,
bstiid:10548,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si10548',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si10558c:{
b:[0,0,57,23],
fh:false,
fw:false,
uid:10558,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'5.864%',
h:'3.783%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'5.864%',
h:'3.783%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'5.864%',
h:'3.783%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10558',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,59,25],
vb:[-2,-2,59,25]
},
si10568:{
name:'Rectangle_4',
type:612,
from:2076,
to:2383,
rp:0,
rpa:0,
mdi:'si10568c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":701,"left":834,"width":300,"height":"auto"}}',
parentGroup:'si10529',
retainState:false,
immo:false,
apsn:'Slide10511',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:10579,
stt:0,
dsr:'Default_State',
stsi:[10568]
}
,{
stn:10591,
stt:102,
dsr:'Failure',
stsi:[10592]
}
,{
stn:10602,
stt:103,
dsr:'Hint',
stsi:[10603]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si10568','si10581','si10592','si10603'],
isDD:false
},
si10568c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10568,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10568',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10581:{
name:'',
type:612,
from:2076,
to:2383,
rp:0,
rpa:0,
mdi:'si10581c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":701,"left":834,"width":300,"height":"auto"}}',
parentGroup:'si10529',
retainState:false,
immo:false,
apsn:'Slide10511',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10568',
stl:[{
stn:'Normal',
stt:0,
stsi:[10581]
}
]
,
stis:0,
bstiid:10568,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10568,
isDD:false
},
si10581c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10581,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10581',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10592:{
name:'',
type:612,
from:2076,
to:2383,
rp:0,
rpa:0,
mdi:'si10592c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":701,"left":834,"width":300,"height":"auto"}}',
parentGroup:'si10529',
retainState:false,
immo:false,
apsn:'Slide10511',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10568',
stl:[{
stn:'Normal',
stt:0,
stsi:[10592]
}
]
,
stis:0,
bstiid:10568,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10568,
isDD:false
},
si10592c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10592,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10592',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10603:{
name:'',
type:612,
from:2076,
to:2383,
rp:0,
rpa:0,
mdi:'si10603c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":701,"left":834,"width":300,"height":"auto"}}',
parentGroup:'si10529',
retainState:false,
immo:false,
apsn:'Slide10511',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10568',
stl:[{
stn:'Normal',
stt:0,
stsi:[10603]
}
]
,
stis:0,
bstiid:10568,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10568,
isDD:false
},
si10603c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10603,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10603',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide10511:{
lb:'Simulation slide 9',
id:10511,
from:2076,
to:2383,
iols:0,
i360qs:false,
sdu:10.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10511c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10537',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
10621:{
ts:''
}

}

},
Slide10511c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10511,
dn:'Slide10511',
visible:'1'
},
si10654:{
name:'Simulation_8',
type:1268,
from:2384,
to:2946,
rp:0,
rpa:0,
mdi:'si10654c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide10628',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10646',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10654c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10654,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10654',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10646:{
name:'Simulation_non_responsive_8',
type:1268,
from:2384,
to:2946,
rp:0,
rpa:0,
mdi:'si10646c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si10654',
retainState:false,
immo:false,
apsn:'Slide10628',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10665',
t:1269
}
,{
n:'si10685',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si10654',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10646c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10646,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10646',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:10662,
tsp:50,
ip:'dr/010662.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10665:{
name:'Click_box_5',
type:1269,
from:2384,
to:2946,
rp:0,
rpa:0,
mdi:'si10665c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.7,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":750,"left":859,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si10646',
retainState:false,
immo:false,
apsn:'Slide10628',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(10738);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:18.729,
lcapid:'si10685',
si:[{
n:'si10675',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10665]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si10665c:{
b:[859,750,893,770],
fh:false,
fw:false,
uid:10665,
iso:false,
css:{
360:{
l:'88.374%',
t:'123.355%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'88.374%',
lhID:-1,
lvEID:0,
lvV:'123.355%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'88.374%',
t:'123.355%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'88.374%',
lhID:-1,
lvEID:0,
lvV:'123.355%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'88.374%',
t:'123.355%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'88.374%',
lhID:-1,
lvEID:0,
lvV:'123.355%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10665',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[859,750,893,770],
vb:[859,750,893,770]
},
si10675:{
name:'Shape_5',
type:612,
from:2384,
to:2946,
rp:0,
rpa:0,
mdi:'si10675c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide10628',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10675]
}
]
,
stis:0,
bstiid:10665,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si10665',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si10675c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:10675,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10675',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si10685:{
name:'Rectangle_5',
type:612,
from:2384,
to:2946,
rp:0,
rpa:0,
mdi:'si10685c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.7,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":810,"left":874,"width":300,"height":"auto"}}',
parentGroup:'si10646',
retainState:false,
immo:false,
apsn:'Slide10628',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:10696,
stt:0,
dsr:'Default_State',
stsi:[10685]
}
,{
stn:10708,
stt:102,
dsr:'Failure',
stsi:[10709]
}
,{
stn:10719,
stt:103,
dsr:'Hint',
stsi:[10720]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si10685','si10698','si10709','si10720'],
isDD:false
},
si10685c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10685,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10685',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10698:{
name:'',
type:612,
from:2384,
to:2946,
rp:0,
rpa:0,
mdi:'si10698c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":810,"left":874,"width":300,"height":"auto"}}',
parentGroup:'si10646',
retainState:false,
immo:false,
apsn:'Slide10628',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10685',
stl:[{
stn:'Normal',
stt:0,
stsi:[10698]
}
]
,
stis:0,
bstiid:10685,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10685,
isDD:false
},
si10698c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10698,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10698',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10709:{
name:'',
type:612,
from:2384,
to:2946,
rp:0,
rpa:0,
mdi:'si10709c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":810,"left":874,"width":300,"height":"auto"}}',
parentGroup:'si10646',
retainState:false,
immo:false,
apsn:'Slide10628',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10685',
stl:[{
stn:'Normal',
stt:0,
stsi:[10709]
}
]
,
stis:0,
bstiid:10685,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10685,
isDD:false
},
si10709c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10709,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10709',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10720:{
name:'',
type:612,
from:2384,
to:2946,
rp:0,
rpa:0,
mdi:'si10720c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":810,"left":874,"width":300,"height":"auto"}}',
parentGroup:'si10646',
retainState:false,
immo:false,
apsn:'Slide10628',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10685',
stl:[{
stn:'Normal',
stt:0,
stsi:[10720]
}
]
,
stis:0,
bstiid:10685,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10685,
isDD:false
},
si10720c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10720,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10720',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide10628:{
lb:'Simulation slide 10',
id:10628,
from:2384,
to:2946,
iols:0,
i360qs:false,
sdu:18.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10628c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10654',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
10738:{
ts:''
}

}

},
Slide10628c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10628,
dn:'Slide10628',
visible:'1'
},
si10771:{
name:'Simulation_9',
type:1268,
from:2947,
to:3597,
rp:0,
rpa:0,
mdi:'si10771c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide10745',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10763',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10771c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10771,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10771',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10763:{
name:'Simulation_non_responsive_9',
type:1268,
from:2947,
to:3597,
rp:0,
rpa:0,
mdi:'si10763c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si10771',
retainState:false,
immo:false,
apsn:'Slide10745',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10782',
t:1269
}
,{
n:'si10802',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si10771',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10763c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10763,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10763',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:10779,
tsp:50,
ip:'dr/010779.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10782:{
name:'Click_box_6',
type:1269,
from:2947,
to:3597,
rp:0,
rpa:0,
mdi:'si10782c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.7,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":750,"left":859,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si10763',
retainState:false,
immo:false,
apsn:'Slide10745',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(10855);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:21.686,
lcapid:'si10802',
si:[{
n:'si10792',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10782]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si10782c:{
b:[859,750,893,770],
fh:false,
fw:false,
uid:10782,
iso:false,
css:{
360:{
l:'88.374%',
t:'123.355%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'88.374%',
lhID:-1,
lvEID:0,
lvV:'123.355%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'88.374%',
t:'123.355%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'88.374%',
lhID:-1,
lvEID:0,
lvV:'123.355%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'88.374%',
t:'123.355%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'88.374%',
lhID:-1,
lvEID:0,
lvV:'123.355%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10782',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[859,750,893,770],
vb:[859,750,893,770]
},
si10792:{
name:'Shape_6',
type:612,
from:2947,
to:3597,
rp:0,
rpa:0,
mdi:'si10792c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide10745',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10792]
}
]
,
stis:0,
bstiid:10782,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si10782',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si10792c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:10792,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10792',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si10802:{
name:'Rectangle_6',
type:612,
from:2947,
to:3597,
rp:0,
rpa:0,
mdi:'si10802c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.7,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":810,"left":874,"width":300,"height":"auto"}}',
parentGroup:'si10763',
retainState:false,
immo:false,
apsn:'Slide10745',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:10813,
stt:0,
dsr:'Default_State',
stsi:[10802]
}
,{
stn:10825,
stt:102,
dsr:'Failure',
stsi:[10826]
}
,{
stn:10836,
stt:103,
dsr:'Hint',
stsi:[10837]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si10802','si10815','si10826','si10837'],
isDD:false
},
si10802c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10802,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10802',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10815:{
name:'',
type:612,
from:2947,
to:3597,
rp:0,
rpa:0,
mdi:'si10815c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":810,"left":874,"width":300,"height":"auto"}}',
parentGroup:'si10763',
retainState:false,
immo:false,
apsn:'Slide10745',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10802',
stl:[{
stn:'Normal',
stt:0,
stsi:[10815]
}
]
,
stis:0,
bstiid:10802,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10802,
isDD:false
},
si10815c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10815,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10815',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10826:{
name:'',
type:612,
from:2947,
to:3597,
rp:0,
rpa:0,
mdi:'si10826c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":810,"left":874,"width":300,"height":"auto"}}',
parentGroup:'si10763',
retainState:false,
immo:false,
apsn:'Slide10745',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10802',
stl:[{
stn:'Normal',
stt:0,
stsi:[10826]
}
]
,
stis:0,
bstiid:10802,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10802,
isDD:false
},
si10826c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10826,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10826',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10837:{
name:'',
type:612,
from:2947,
to:3597,
rp:0,
rpa:0,
mdi:'si10837c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":810,"left":874,"width":300,"height":"auto"}}',
parentGroup:'si10763',
retainState:false,
immo:false,
apsn:'Slide10745',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10802',
stl:[{
stn:'Normal',
stt:0,
stsi:[10837]
}
]
,
stis:0,
bstiid:10802,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10802,
isDD:false
},
si10837c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10837,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10837',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide10745:{
lb:'Simulation slide 11',
id:10745,
from:2947,
to:3597,
iols:0,
i360qs:false,
sdu:21.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10745c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10771',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
10855:{
ts:''
}

}

},
Slide10745c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10745,
dn:'Slide10745',
visible:'1'
},
si10880:{
name:'Video_3',
type:1268,
from:3598,
to:3612,
rp:0,
rpa:0,
mdi:'si10880c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide10862',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10899',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10880c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10880,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10880',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10899:{
name:'SlideVideo_29',
type:365,
from:3598,
to:3612,
rp:0,
rpa:0,
mdi:'si10899c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.5,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si10880',
retainState:false,
immo:false,
apsn:'Slide10862',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si10899c:{
b:[-161,-206,1133,814],
fh:false,
fw:false,
uid:10899,
iso:false,
css:{
360:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10899',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/010895.png',
mp4:'vr/Vi10888.mp4',
vsf:0,
vst:0.5,
o:100,
vbwr:[-162,-207,1134,815],
vb:[-162,-207,1134,815]
},
Slide10862:{
lb:'Simulation slide 12',
id:10862,
from:3598,
to:3612,
iols:0,
i360qs:false,
sdu:0.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10862c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10880',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide10862c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10862,
dn:'Slide10862',
visible:'1'
},
si10932:{
name:'Simulation_10',
type:1268,
from:3613,
to:3777,
rp:0,
rpa:0,
mdi:'si10932c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide10906',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10924',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10932c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10932,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10932',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10924:{
name:'Simulation_non_responsive_10',
type:1268,
from:3613,
to:3777,
rp:0,
rpa:0,
mdi:'si10924c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si10932',
retainState:false,
immo:false,
apsn:'Slide10906',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si10943',
t:1269
}
,{
n:'si10963',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si10932',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si10924c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:10924,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10924',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:10940,
tsp:50,
ip:'dr/010940.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si10943:{
name:'Click_box_7',
type:1269,
from:3613,
to:3777,
rp:0,
rpa:0,
mdi:'si10943c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.5,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":598,"left":486,"width":221,"height":27},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si10924',
retainState:false,
immo:false,
apsn:'Slide10906',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(11016);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:5.472,
lcapid:'si10963',
si:[{
n:'si10953',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10943]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si10943c:{
b:[486,598,707,625],
fh:false,
fw:false,
uid:10943,
iso:false,
css:{
360:{
l:'50.000%',
t:'98.355%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.000%',
lhID:-1,
lvEID:0,
lvV:'98.355%',
lvID:-1,
w:'22.737%',
h:'4.441%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'50.000%',
t:'98.355%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.000%',
lhID:-1,
lvEID:0,
lvV:'98.355%',
lvID:-1,
w:'22.737%',
h:'4.441%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'50.000%',
t:'98.355%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.000%',
lhID:-1,
lvEID:0,
lvV:'98.355%',
lvID:-1,
w:'22.737%',
h:'4.441%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si10943',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[486,598,707,625],
vb:[486,598,707,625]
},
si10953:{
name:'Shape_7',
type:612,
from:3613,
to:3777,
rp:0,
rpa:0,
mdi:'si10953c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide10906',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[10953]
}
]
,
stis:0,
bstiid:10943,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si10943',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si10953c:{
b:[0,0,221,27],
fh:false,
fw:false,
uid:10953,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'22.737%',
h:'4.441%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'22.737%',
h:'4.441%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'22.737%',
h:'4.441%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10953',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,223,29],
vb:[-2,-2,223,29]
},
si10963:{
name:'Rectangle_7',
type:612,
from:3613,
to:3777,
rp:0,
rpa:0,
mdi:'si10963c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.5,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":658,"left":501,"width":300,"height":"auto"}}',
parentGroup:'si10924',
retainState:false,
immo:false,
apsn:'Slide10906',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:10974,
stt:0,
dsr:'Default_State',
stsi:[10963]
}
,{
stn:10986,
stt:102,
dsr:'Failure',
stsi:[10987]
}
,{
stn:10997,
stt:103,
dsr:'Hint',
stsi:[10998]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si10963','si10976','si10987','si10998'],
isDD:false
},
si10963c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10963,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10963',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10976:{
name:'',
type:612,
from:3613,
to:3777,
rp:0,
rpa:0,
mdi:'si10976c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":658,"left":501,"width":300,"height":"auto"}}',
parentGroup:'si10924',
retainState:false,
immo:false,
apsn:'Slide10906',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10963',
stl:[{
stn:'Normal',
stt:0,
stsi:[10976]
}
]
,
stis:0,
bstiid:10963,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10963,
isDD:false
},
si10976c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10976,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10976',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10987:{
name:'',
type:612,
from:3613,
to:3777,
rp:0,
rpa:0,
mdi:'si10987c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":658,"left":501,"width":300,"height":"auto"}}',
parentGroup:'si10924',
retainState:false,
immo:false,
apsn:'Slide10906',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10963',
stl:[{
stn:'Normal',
stt:0,
stsi:[10987]
}
]
,
stis:0,
bstiid:10963,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10963,
isDD:false
},
si10987c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10987,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10987',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si10998:{
name:'',
type:612,
from:3613,
to:3777,
rp:0,
rpa:0,
mdi:'si10998c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":658,"left":501,"width":300,"height":"auto"}}',
parentGroup:'si10924',
retainState:false,
immo:false,
apsn:'Slide10906',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si10963',
stl:[{
stn:'Normal',
stt:0,
stsi:[10998]
}
]
,
stis:0,
bstiid:10963,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:10963,
isDD:false
},
si10998c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:10998,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si10998',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide10906:{
lb:'Simulation slide 13',
id:10906,
from:3613,
to:3777,
iols:0,
i360qs:false,
sdu:5.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide10906c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si10932',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
11016:{
ts:''
}

}

},
Slide10906c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:10906,
dn:'Slide10906',
visible:'1'
},
si11049:{
name:'Simulation_11',
type:1268,
from:3778,
to:3853,
rp:0,
rpa:0,
mdi:'si11049c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide11023',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si11041',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11049c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11049,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11049',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si11041:{
name:'Simulation_non_responsive_11',
type:1268,
from:3778,
to:3853,
rp:0,
rpa:0,
mdi:'si11041c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si11049',
retainState:false,
immo:false,
apsn:'Slide11023',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si11060',
t:1269
}
,{
n:'si11080',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si11049',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11041c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11041,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11041',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:11057,
tsp:50,
ip:'dr/011057.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si11060:{
name:'Click_box_8',
type:1269,
from:3778,
to:3853,
rp:0,
rpa:0,
mdi:'si11060c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.5,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":625,"left":488,"width":220,"height":50},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si11041',
retainState:false,
immo:false,
apsn:'Slide11023',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(11133);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:2.5,
lcapid:'si11080',
si:[{
n:'si11070',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[11060]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si11060c:{
b:[488,625,708,675],
fh:false,
fw:false,
uid:11060,
iso:false,
css:{
360:{
l:'50.206%',
t:'102.796%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.206%',
lhID:-1,
lvEID:0,
lvV:'102.796%',
lvID:-1,
w:'22.634%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'50.206%',
t:'102.796%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.206%',
lhID:-1,
lvEID:0,
lvV:'102.796%',
lvID:-1,
w:'22.634%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'50.206%',
t:'102.796%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.206%',
lhID:-1,
lvEID:0,
lvV:'102.796%',
lvID:-1,
w:'22.634%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11060',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[488,625,708,675],
vb:[488,625,708,675]
},
si11070:{
name:'Shape_8',
type:612,
from:3778,
to:3853,
rp:0,
rpa:0,
mdi:'si11070c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide11023',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[11070]
}
]
,
stis:0,
bstiid:11060,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si11060',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si11070c:{
b:[0,0,220,50],
fh:false,
fw:false,
uid:11070,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'22.634%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'22.634%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'22.634%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11070',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,222,52],
vb:[-2,-2,222,52]
},
si11080:{
name:'Rectangle_8',
type:612,
from:3778,
to:3853,
rp:0,
rpa:0,
mdi:'si11080c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.5,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":685,"left":503,"width":300,"height":"auto"}}',
parentGroup:'si11041',
retainState:false,
immo:false,
apsn:'Slide11023',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:11091,
stt:0,
dsr:'Default_State',
stsi:[11080]
}
,{
stn:11103,
stt:102,
dsr:'Failure',
stsi:[11104]
}
,{
stn:11114,
stt:103,
dsr:'Hint',
stsi:[11115]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si11080','si11093','si11104','si11115'],
isDD:false
},
si11080c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11080,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11080',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si11093:{
name:'',
type:612,
from:3778,
to:3853,
rp:0,
rpa:0,
mdi:'si11093c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":685,"left":503,"width":300,"height":"auto"}}',
parentGroup:'si11041',
retainState:false,
immo:false,
apsn:'Slide11023',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si11080',
stl:[{
stn:'Normal',
stt:0,
stsi:[11093]
}
]
,
stis:0,
bstiid:11080,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:11080,
isDD:false
},
si11093c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11093,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11093',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si11104:{
name:'',
type:612,
from:3778,
to:3853,
rp:0,
rpa:0,
mdi:'si11104c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":685,"left":503,"width":300,"height":"auto"}}',
parentGroup:'si11041',
retainState:false,
immo:false,
apsn:'Slide11023',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si11080',
stl:[{
stn:'Normal',
stt:0,
stsi:[11104]
}
]
,
stis:0,
bstiid:11080,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:11080,
isDD:false
},
si11104c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11104,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11104',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si11115:{
name:'',
type:612,
from:3778,
to:3853,
rp:0,
rpa:0,
mdi:'si11115c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":685,"left":503,"width":300,"height":"auto"}}',
parentGroup:'si11041',
retainState:false,
immo:false,
apsn:'Slide11023',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si11080',
stl:[{
stn:'Normal',
stt:0,
stsi:[11115]
}
]
,
stis:0,
bstiid:11080,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:11080,
isDD:false
},
si11115c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11115,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11115',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide11023:{
lb:'Simulation slide 14',
id:11023,
from:3778,
to:3853,
iols:0,
i360qs:false,
sdu:2.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide11023c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si11049',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
11133:{
ts:''
}

}

},
Slide11023c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:11023,
dn:'Slide11023',
visible:'1'
},
si11166:{
name:'Simulation_12',
type:1268,
from:3854,
to:3853,
rp:0,
rpa:0,
mdi:'si11166c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide11140',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si11158',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11166c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11166,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11166',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si11158:{
name:'Simulation_non_responsive_12',
type:1268,
from:3854,
to:3853,
rp:0,
rpa:0,
mdi:'si11158c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si11166',
retainState:false,
immo:false,
apsn:'Slide11140',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si11166',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11158c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11158,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11158',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:11174,
tsp:50,
ip:'dr/011174.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide11140:{
lb:'Simulation slide 15',
id:11140,
from:3854,
to:3948,
iols:0,
i360qs:false,
sdu:3.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide11140c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si11166',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide11140c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:11140,
dn:'Slide11140',
visible:'1'
},
si11195:{
name:'Video_4',
type:1268,
from:3949,
to:3963,
rp:0,
rpa:0,
mdi:'si11195c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide11177',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si11214',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11195c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11195,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11195',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si11214:{
name:'SlideVideo_30',
type:365,
from:3949,
to:3963,
rp:0,
rpa:0,
mdi:'si11214c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.5,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si11195',
retainState:false,
immo:false,
apsn:'Slide11177',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si11214c:{
b:[-161,-206,1133,814],
fh:false,
fw:false,
uid:11214,
iso:false,
css:{
360:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-16.564%',
t:'-33.882%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-16.564%',
lhID:-1,
lvEID:0,
lvV:'-33.882%',
lvID:-1,
w:'133.128%',
h:'167.763%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11214',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/011210.png',
mp4:'vr/Vi11203.mp4',
vsf:0,
vst:0.5,
o:100,
vbwr:[-162,-207,1134,815],
vb:[-162,-207,1134,815]
},
Slide11177:{
lb:'Simulation slide 16',
id:11177,
from:3949,
to:3963,
iols:0,
i360qs:false,
sdu:0.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide11177c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si11195',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide11177c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:11177,
dn:'Slide11177',
visible:'1'
},
si11247:{
name:'Simulation_13',
type:1268,
from:3964,
to:4122,
rp:0,
rpa:0,
mdi:'si11247c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide11221',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si11239',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11247c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11247,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11247',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si11239:{
name:'Simulation_non_responsive_13',
type:1268,
from:3964,
to:4122,
rp:0,
rpa:0,
mdi:'si11239c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si11247',
retainState:false,
immo:false,
apsn:'Slide11221',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si11258',
t:1269
}
,{
n:'si11278',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si11247',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11239c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11239,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11239',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:11255,
tsp:50,
ip:'dr/011255.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si11258:{
name:'Click_box_9',
type:1269,
from:3964,
to:4122,
rp:0,
rpa:0,
mdi:'si11258c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":830,"left":762,"width":132,"height":29},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si11239',
retainState:false,
immo:false,
apsn:'Slide11221',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(11331);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:5.29,
lcapid:'si11278',
si:[{
n:'si11268',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[11258]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si11258c:{
b:[762,830,894,859],
fh:false,
fw:false,
uid:11258,
iso:false,
css:{
360:{
l:'78.395%',
t:'136.513%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'78.395%',
lhID:-1,
lvEID:0,
lvV:'136.513%',
lvID:-1,
w:'13.580%',
h:'4.770%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'78.395%',
t:'136.513%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'78.395%',
lhID:-1,
lvEID:0,
lvV:'136.513%',
lvID:-1,
w:'13.580%',
h:'4.770%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'78.395%',
t:'136.513%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'78.395%',
lhID:-1,
lvEID:0,
lvV:'136.513%',
lvID:-1,
w:'13.580%',
h:'4.770%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11258',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[762,830,894,859],
vb:[762,830,894,859]
},
si11268:{
name:'Shape_9',
type:612,
from:3964,
to:4122,
rp:0,
rpa:0,
mdi:'si11268c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide11221',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[11268]
}
]
,
stis:0,
bstiid:11258,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si11258',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si11268c:{
b:[0,0,132,29],
fh:false,
fw:false,
uid:11268,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.580%',
h:'4.770%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.580%',
h:'4.770%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.580%',
h:'4.770%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11268',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,134,31],
vb:[-2,-2,134,31]
},
si11278:{
name:'Rectangle_9',
type:612,
from:3964,
to:4122,
rp:0,
rpa:0,
mdi:'si11278c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":890,"left":777,"width":300,"height":"auto"}}',
parentGroup:'si11239',
retainState:false,
immo:false,
apsn:'Slide11221',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:11289,
stt:0,
dsr:'Default_State',
stsi:[11278]
}
,{
stn:11301,
stt:102,
dsr:'Failure',
stsi:[11302]
}
,{
stn:11312,
stt:103,
dsr:'Hint',
stsi:[11313]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si11278','si11291','si11302','si11313'],
isDD:false
},
si11278c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11278,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11278',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si11291:{
name:'',
type:612,
from:3964,
to:4122,
rp:0,
rpa:0,
mdi:'si11291c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":890,"left":777,"width":300,"height":"auto"}}',
parentGroup:'si11239',
retainState:false,
immo:false,
apsn:'Slide11221',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si11278',
stl:[{
stn:'Normal',
stt:0,
stsi:[11291]
}
]
,
stis:0,
bstiid:11278,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:11278,
isDD:false
},
si11291c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11291,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11291',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si11302:{
name:'',
type:612,
from:3964,
to:4122,
rp:0,
rpa:0,
mdi:'si11302c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":890,"left":777,"width":300,"height":"auto"}}',
parentGroup:'si11239',
retainState:false,
immo:false,
apsn:'Slide11221',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si11278',
stl:[{
stn:'Normal',
stt:0,
stsi:[11302]
}
]
,
stis:0,
bstiid:11278,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:11278,
isDD:false
},
si11302c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11302,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11302',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si11313:{
name:'',
type:612,
from:3964,
to:4122,
rp:0,
rpa:0,
mdi:'si11313c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":890,"left":777,"width":300,"height":"auto"}}',
parentGroup:'si11239',
retainState:false,
immo:false,
apsn:'Slide11221',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si11278',
stl:[{
stn:'Normal',
stt:0,
stsi:[11313]
}
]
,
stis:0,
bstiid:11278,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:11278,
isDD:false
},
si11313c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11313,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11313',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide11221:{
lb:'Simulation slide 17',
id:11221,
from:3964,
to:4122,
iols:0,
i360qs:false,
sdu:5.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide11221c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si11247',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
11331:{
ts:''
}

}

},
Slide11221c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:11221,
dn:'Slide11221',
visible:'1'
},
si11364:{
name:'Simulation_14',
type:1268,
from:4123,
to:4382,
rp:0,
rpa:0,
mdi:'si11364c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide11338',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si11356',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11364c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11364,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11364',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si11356:{
name:'Simulation_non_responsive_14',
type:1268,
from:4123,
to:4382,
rp:0,
rpa:0,
mdi:'si11356c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si11364',
retainState:false,
immo:false,
apsn:'Slide11338',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si11375',
t:1269
}
,{
n:'si11395',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si11364',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11356c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11356,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11356',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:11372,
tsp:50,
ip:'dr/011372.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si11375:{
name:'Click_box_10',
type:1269,
from:4123,
to:4382,
rp:0,
rpa:0,
mdi:'si11375c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":200,"left":10,"width":179,"height":70},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si11356',
retainState:false,
immo:false,
apsn:'Slide11338',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(11448);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:8.629,
lcapid:'si11395',
si:[{
n:'si11385',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[11375]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si11375c:{
b:[10,200,189,270],
fh:false,
fw:false,
uid:11375,
iso:false,
css:{
360:{
l:'1.029%',
t:'32.895%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'1.029%',
lhID:-1,
lvEID:0,
lvV:'32.895%',
lvID:-1,
w:'18.416%',
h:'11.513%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'1.029%',
t:'32.895%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'1.029%',
lhID:-1,
lvEID:0,
lvV:'32.895%',
lvID:-1,
w:'18.416%',
h:'11.513%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'1.029%',
t:'32.895%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'1.029%',
lhID:-1,
lvEID:0,
lvV:'32.895%',
lvID:-1,
w:'18.416%',
h:'11.513%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11375',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[10,200,189,270],
vb:[10,200,189,270]
},
si11385:{
name:'Shape_10',
type:612,
from:4123,
to:4382,
rp:0,
rpa:0,
mdi:'si11385c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide11338',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[11385]
}
]
,
stis:0,
bstiid:11375,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si11375',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si11385c:{
b:[0,0,179,70],
fh:false,
fw:false,
uid:11385,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.416%',
h:'11.513%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.416%',
h:'11.513%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.416%',
h:'11.513%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11385',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,181,72],
vb:[-2,-2,181,72]
},
si11395:{
name:'Rectangle_10',
type:612,
from:4123,
to:4382,
rp:0,
rpa:0,
mdi:'si11395c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":260,"left":25,"width":300,"height":"auto"}}',
parentGroup:'si11356',
retainState:false,
immo:false,
apsn:'Slide11338',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:11406,
stt:0,
dsr:'Default_State',
stsi:[11395]
}
,{
stn:11418,
stt:102,
dsr:'Failure',
stsi:[11419]
}
,{
stn:11429,
stt:103,
dsr:'Hint',
stsi:[11430]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si11395','si11408','si11419','si11430'],
isDD:false
},
si11395c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11395,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11395',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si11408:{
name:'',
type:612,
from:4123,
to:4382,
rp:0,
rpa:0,
mdi:'si11408c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":260,"left":25,"width":300,"height":"auto"}}',
parentGroup:'si11356',
retainState:false,
immo:false,
apsn:'Slide11338',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si11395',
stl:[{
stn:'Normal',
stt:0,
stsi:[11408]
}
]
,
stis:0,
bstiid:11395,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:11395,
isDD:false
},
si11408c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11408,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11408',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si11419:{
name:'',
type:612,
from:4123,
to:4382,
rp:0,
rpa:0,
mdi:'si11419c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":260,"left":25,"width":300,"height":"auto"}}',
parentGroup:'si11356',
retainState:false,
immo:false,
apsn:'Slide11338',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si11395',
stl:[{
stn:'Normal',
stt:0,
stsi:[11419]
}
]
,
stis:0,
bstiid:11395,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:11395,
isDD:false
},
si11419c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11419,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11419',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si11430:{
name:'',
type:612,
from:4123,
to:4382,
rp:0,
rpa:0,
mdi:'si11430c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":260,"left":25,"width":300,"height":"auto"}}',
parentGroup:'si11356',
retainState:false,
immo:false,
apsn:'Slide11338',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si11395',
stl:[{
stn:'Normal',
stt:0,
stsi:[11430]
}
]
,
stis:0,
bstiid:11395,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:11395,
isDD:false
},
si11430c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:11430,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si11430',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide11338:{
lb:'Simulation slide 18',
id:11338,
from:4123,
to:4382,
iols:0,
i360qs:false,
sdu:8.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide11338c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si11364',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
11448:{
ts:''
}

}

},
Slide11338c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:11338,
dn:'Slide11338',
visible:'1'
},
si11481:{
name:'Simulation_15',
type:1268,
from:4383,
to:4382,
rp:0,
rpa:0,
mdi:'si11481c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide11455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si11473',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11481c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11481,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11481',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si11473:{
name:'Simulation_non_responsive_15',
type:1268,
from:4383,
to:4382,
rp:0,
rpa:0,
mdi:'si11473c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si11481',
retainState:false,
immo:false,
apsn:'Slide11455',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1294,"height":1020},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si11481',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si11473c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:11473,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si11473',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1294,
h:1020,
id:11489,
tsp:50,
ip:'dr/011489.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide11455:{
lb:'Simulation slide 19',
id:11455,
from:4383,
to:4768,
iols:0,
i360qs:false,
sdu:12.8,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide11455c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si11481',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide11455c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:11455,
dn:'Slide11455',
visible:'1'
},
StAd1:{
from:1,
to:4741,
src:'ar/StAd0.mp3',
du:158426,
saup:[{
sn:388,
del:0,
du:21.3082,
l:false
}
,{
sn:9961,
del:0,
du:14.5,
l:false
}
,{
sn:10078,
del:0,
du:1.4,
l:false
}
,{
sn:10115,
del:0,
du:13.4,
l:false
}
,{
sn:10232,
del:0,
du:5.5,
l:false
}
,{
sn:10269,
del:0,
du:0.4,
l:false
}
,{
sn:10313,
del:0,
du:0.3,
l:false
}
,{
sn:10350,
del:0,
du:1.1,
l:false
}
,{
sn:10394,
del:0,
du:11.1,
l:false
}
,{
sn:10511,
del:0,
du:10.2,
l:false
}
,{
sn:10628,
del:0,
du:18.7,
l:false
}
,{
sn:10745,
del:0,
du:21.7,
l:false
}
,{
sn:10862,
del:0,
du:0.5,
l:false
}
,{
sn:10906,
del:0,
du:5.5,
l:false
}
,{
sn:11023,
del:0,
du:2.5,
l:false
}
,{
sn:11140,
del:0,
du:3.1,
l:false
}
,{
sn:11177,
del:0,
du:0.5,
l:false
}
,{
sn:11221,
del:0,
du:5.31837,
l:false
}
,{
sn:11338,
del:0,
du:8.6,
l:false
}
,{
sn:11455,
del:0,
du:12.8,
l:false
}
]

},
quizzingData:{
allowBackwardMovement:true,
allowReviewMode:true,
reviewShowAnswers:true,
it:false,
firstSlideInQuiz:-1,
lastSlideInQuiz:-1,
quizScopeEndSlide:-1,
maxScore:0,
minScore:0,
maxPretestScore:0,
numQuestionsInQuiz:0,
numQuizAttemptsAllowed:1,
passingScore:0,
quizInfoCurrentAttempt:0,
quizInfoPercentScored:0,
quizMandateLevel:0,
quizID:199,
questionPoolsInitialized:true,
quizInfoAttempts:1,
quizInfoLastSlidePointScored:0,
quizInfoMaxAttemptsOnCurrentQuestion:1,
quizInfoPassFail:0,
quizInfoPointsPerQuestionSlide:0,
quizInfoPointsScored:0,
quizInfoQuizPassPercent:80,
quizInfoQuizPassPoints:0,
quizInfoTotalCorrectAnswers:0,
quizInfoTotalProjectPoints:0,
quizInfoTotalQuestionsPerProject:0,
quizInfoTotalQuizPoints:0,
quizInfoTotalUnansweredQuestions:0,
reportingEnabled:false,
submitAll:false,
hidePlaybarInQuiz:false,
quizBranchAware:false,
passFailPassingScoreTypeInPrecent:true,
passFailPassingScoreValue:80,
showRetake:false,
showReviewButtons:true,
oid:'$$OBJECTIVE_ID',
quizVariableVsIdMap:{
learnerId:'var346',
learnerName:'var347',
isInQuizScope:'var368',
isInReviewMode:'var369',
quizInfoPercentScored:'var370',
quizInfoAttempts:'var371',
quizInfoPassFail:'var372',
score:'var373',
quizInfoQuizPassPercent:'var374',
passingScore:'var375',
quizInfoTotalCorrectAnswers:'var376',
maxScore:'var377',
quizInfoTotalQuestionsPerProject:'var378',
quizInfoTotalUnansweredQuestions:'var379',
quizInfoAnswerChoice:'var380',
quizInfoPreviousQuestionScore:'var381',
questionInfoMaxAttempts:'var382',
questionInfoNegativePoints:'var383',
questionInfoPointsAssigned:'var384'
}

},
var346var346:{
vid:346,
name:'LMS.LearnerID',
vv:'',
vvt:2,
vt:0
},
var347var347:{
vid:347,
name:'LMS.LearnerName',
vv:'',
vvt:2,
vt:0
},
var348var348:{
vid:348,
name:'LMS.CourseName',
vv:'',
vvt:2,
vt:0
},
var349var349:{
vid:349,
name:'Project.ClosedCaptions',
vv:1,
vvt:0,
vt:9
},
var350var350:{
vid:350,
name:'Project.MuteAudio',
vv:0,
vvt:0,
vt:9
},
var351var351:{
vid:351,
name:'Project.ShowPlaybar',
vv:1,
vvt:0,
vt:9
},
var352var352:{
vid:352,
name:'Project.ShowTOC',
vv:0,
vvt:0,
vt:9
},
var353var353:{
vid:353,
name:'Project.AudioLevel',
vv:100,
vvt:1,
vt:9
},
var354var354:{
vid:354,
name:'Project.LockTOC',
vv:0,
vvt:0,
vt:9
},
var355var355:{
vid:355,
name:'Project.CurrentSlideNumber',
vv:1,
vvt:1,
vt:9
},
var356var356:{
vid:356,
name:'Project.CurrentSlideName',
vv:'slide',
vvt:2,
vt:9
},
var357var357:{
vid:357,
name:'Project.SlideCount',
vv:1,
vvt:1,
vt:9
},
var358var358:{
vid:358,
name:'Date.Today',
vv:'dd',
vvt:3,
vt:5
},
var359var359:{
vid:359,
name:'Date.DateMMDDYY',
vv:'mm/dd/yyyy',
vvt:3,
vt:5
},
var360var360:{
vid:360,
name:'Date.DateDDMMYY',
vv:'dd/mm/yyyy',
vvt:3,
vt:5
},
var361var361:{
vid:361,
name:'Date.Day',
vv:'1',
vvt:3,
vt:5
},
var362var362:{
vid:362,
name:'Date.Hours',
vv:'hh',
vvt:3,
vt:5
},
var363var363:{
vid:363,
name:'Date.LocaleString',
vv:'',
vvt:3,
vt:5
},
var364var364:{
vid:364,
name:'Date.Minutes',
vv:'mm',
vvt:3,
vt:5
},
var365var365:{
vid:365,
name:'Date.Month',
vv:'mm',
vvt:3,
vt:5
},
var366var366:{
vid:366,
name:'Date.Time',
vv:'hh:mm:ss',
vvt:3,
vt:5
},
var367var367:{
vid:367,
name:'Date.Year',
vv:'yyyy',
vvt:3,
vt:5
},
var368var368:{
vid:368,
name:'Quiz.InScope',
vv:0,
vvt:0,
vt:7
},
var369var369:{
vid:369,
name:'Quiz.InReview',
vv:0,
vvt:0,
vt:7
},
var370var370:{
vid:370,
name:'Quiz.PercentageScore',
vv:'0',
vvt:2,
vt:7
},
var371var371:{
vid:371,
name:'Quiz.AttemptCount',
vv:0,
vvt:1,
vt:7
},
var372var372:{
vid:372,
name:'Quiz.Pass',
vv:0,
vvt:0,
vt:7
},
var373var373:{
vid:373,
name:'Quiz.Score',
vv:0,
vvt:1,
vt:7
},
var374var374:{
vid:374,
name:'Quiz.PassPercentage',
vv:80,
vvt:1,
vt:7
},
var375var375:{
vid:375,
name:'Quiz.PassPoints',
vv:0,
vvt:1,
vt:7
},
var376var376:{
vid:376,
name:'Quiz.CorrectAnswerCount',
vv:0,
vvt:1,
vt:7
},
var377var377:{
vid:377,
name:'Quiz.MaxScore',
vv:0,
vvt:1,
vt:7
},
var378var378:{
vid:378,
name:'Quiz.QuestionCount',
vv:0,
vvt:1,
vt:7
},
var379var379:{
vid:379,
name:'Quiz.UnansweredQuestionCount',
vv:0,
vvt:1,
vt:7
},
var380var380:{
vid:380,
name:'Question.AnswerChoice',
vv:'',
vvt:2,
vt:7
},
var381var381:{
vid:381,
name:'Question.PreviousQuestionScore',
vv:0,
vvt:1,
vt:7
},
var382var382:{
vid:382,
name:'Question.MaxAttempts',
vv:0,
vvt:1,
vt:7
},
var383var383:{
vid:383,
name:'Question.NegativePoints',
vv:0,
vvt:1,
vt:7
},
var384var384:{
vid:384,
name:'Question.PointsAssigned',
vv:0,
vvt:1,
vt:7
},
variableIdVsNameMap:{
var346:'LMS.LearnerID',
var347:'LMS.LearnerName',
var348:'LMS.CourseName',
var349:'Project.ClosedCaptions',
var350:'Project.MuteAudio',
var351:'Project.ShowPlaybar',
var352:'Project.ShowTOC',
var353:'Project.AudioLevel',
var354:'Project.LockTOC',
var355:'Project.CurrentSlideNumber',
var356:'Project.CurrentSlideName',
var357:'Project.SlideCount',
var358:'Date.Today',
var359:'Date.DateMMDDYY',
var360:'Date.DateDDMMYY',
var361:'Date.Day',
var362:'Date.Hours',
var363:'Date.LocaleString',
var364:'Date.Minutes',
var365:'Date.Month',
var366:'Date.Time',
var367:'Date.Year',
var368:'Quiz.InScope',
var369:'Quiz.InReview',
var370:'Quiz.PercentageScore',
var371:'Quiz.AttemptCount',
var372:'Quiz.Pass',
var373:'Quiz.Score',
var374:'Quiz.PassPercentage',
var375:'Quiz.PassPoints',
var376:'Quiz.CorrectAnswerCount',
var377:'Quiz.MaxScore',
var378:'Quiz.QuestionCount',
var379:'Quiz.UnansweredQuestionCount',
var380:'Question.AnswerChoice',
var381:'Question.PreviousQuestionScore',
var382:'Question.MaxAttempts',
var383:'Question.NegativePoints',
var384:'Question.PointsAssigned'
},
project:{
fps:30,
hasTOC:1,
hasCC:false,
showClosedCaptions:true,
w:1920,
h:1024,
iw:1366,
ih:768,
prm:[1,1,0,0],
stateNameToLocalizedStateNameMap:{
kCPNormalState:'Normal',
kCPDownState:'Click',
kCPRolloverState:'Hover',
kCPVisitedState:'Visited',
kCPDragoverState:'',
kCPDragstartState:'',
kCPDropCorrect:'',
kCPDropIncorrect:'',
kCPDropAccept:'',
kCPDropReject:''
}
,
prjBgColor:'#ffffff',
pkt:0,
htmlBgColor:'#f5f4f1',
shc:false,
pN:'Lab 2.cpt'
},
projectThemeData:{
image_presets:'{\\
  "theme_image_default": {\\
    "meta": {\\
      "name": "kCPImageStyleNormal",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_default--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_default--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Normal",\\
        "mixBlendMode": "normal"\\
      }\\
    }\\
  },\\
\\
  "theme_image_greyscale": {\\
    "meta": {\\
      "name": "kCPImageStyleGreyscale",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_greyscale--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_greyscale--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Greyscale",\\
        "mixBlendMode": "saturation",\\
        "intensity": "var(--theme_image_greyscale--intensity)",\\
        "filterColor": {\\
          "fill": "#000000",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_lighten": {\\
    "meta": {\\
      "name": "kCPImageStyleLighten",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_lighten--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_lighten--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Lighten",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_lighten--intensity)",\\
        "filterColor": {\\
          "fill": "#FFFFFF",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_darken": {\\
    "meta": {\\
      "name": "kCPImageStyleDarken",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_darken--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_darken--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Darken",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_darken--intensity)",\\
        "filterColor": {\\
          "fill": "var(--black)",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_overlay": {\\
    "meta": {\\
      "name": "kCPImageStyleOverlay",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_overlay--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_overlay--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Overlay",\\
        "mixBlendMode": "overlay",\\
        "intensity": "var(--theme_image_overlay--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_overlay--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_colorize": {\\
    "meta": {\\
      "name": "kCPImageStyleColorize",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_colorize--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_colorize--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Colorize",\\
        "mixBlendMode": "color",\\
        "intensity": "var(--theme_image_colorize--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_colorize--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  }\\
}\\
',
meta:'{\\
  "name": "kCPThemeLight",\\
  "description": "kCPThemeLightDescription",\\
  "version": 0.1,\\
  "guid": "Default-Light-Theme",\\
  "default_presets": {\\
    "0": "cp_default_shape_solid_style",\\
    "1": "text-body-1",\\
    "2": "theme_image_default",\\
    "3": "cp_default_slide_style",\\
    "4": "cp_textinshape_body_1",\\
    "5": "cp_default_line_shape_style",\\
    "6": "cp_default_complex_shape_solid_style",\\
    "7": "cp_button_style_1_textonly",\\
    "8": "cp_checkbox_style_1_textonly",\\
    "9": "cp_svg_style",\\
    "10": "cp_dropDown_style_1",\\
    "11": "cp_radiobutton_style_1_textonly",\\
    "12": "cp_inputField_style_1",\\
    "13": "cp_clickbox_style",\\
    "14": "cp_responsive_container_style",\\
    "15": "cp_default_shape_solid_style"\\
  },\\
  "color_palettes": [\\
    {\\
      "name": "Light Palette - 1",\\
      "colors": [\\
        "var(--color1)",\\
        "var(--color2)",\\
        "var(--color3)",\\
        "var(--color4)",\\
        "var(--color5)",\\
        "var(--color6)",\\
        "var(--color7)",\\
        "var(--color5_light)",\\
        "var(--color4_dark)"\\
      ]\\
    }\\
  ],\\
  "active_color_palette": 0\\
}',
other_presets:'{\\
  "cp_default_slide_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "type": 3,\\
      "category": 0\\
    },\\
    "backgroundColor": "var(--palette-color1)",\\
    "outlineColor": "var(--palette-color5)",\\
    "outlineWidth": 1,\\
    "outlineStyle": "solid",\\
    "outlineCap": "butt",\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 0,\\
            "y": 0\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_responsive_container_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 14,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": 1,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_correct": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--success)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incorrect": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--error)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incomplete": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--incomplete)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_hint": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--hint)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_retry": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--retry)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_timeout": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--timeout)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color1)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_radial_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}',
theme:'{\\
  "--primary": "#F1EEE6",\\
\\
  "--color1": "#FFFFFF",\\
  "--color2": "#F8F7F4",\\
  "--color3": "#F1EEE6",\\
  "--color4": "#D6D5D1",\\
  "--color5": "#666666",\\
  "--color6": "#333333",\\
  "--color7": "#020C1C",\\
  "--colorC7": "#F7F7F7",\\
  "--disabledC12": "#989898",\\
  "--color1_light": "#FFCD74",\\
  "--color1_dark": "#C76D12",\\
  "--color2_light": "#86FFFF",\\
  "--color2_dark": "#00ACCC",\\
  "--color3_light": "#9B5DFF",\\
  "--color3_dark": "#0000CA",\\
  "--color4_light": "#99FF99",\\
  "--color4_dark": "#112FA7",\\
  "--color5_light": "#163EE5",\\
  "--color5_dark": "#00CB92",\\
  "--color6_light": "#7697FF",\\
  "--color6_dark": "#0040CB",\\
  "--color7_light": "#FF8E64",\\
  "--color7_dark": "#C5230B",\\
\\
  "--success": "#558564",\\
  "--error": "#C83E4D",\\
  "--hint": "#CB6F10",\\
  "--incomplete":"#E8BD2B",\\
  "--timeout": "#C74545",\\
  "--retry": "#CB6F10",\\
  "--white": "#ffffff",\\
  "--black": "#000000",\\
\\
  "--greyscale1": "#FFFFFF",\\
  "--greyscale2": "#F1EEE61F",\\
  "--greyscale3": "#B3B3B3",\\
  "--greyscale4": "#4B4B4B",\\
  "--greyscale5": "#333333",\\
  "--disabled": "#818181",\\
\\
  "--palette-color0": "var(--color1)",\\
  "--palette-color1": "var(--color2)",\\
  "--palette-color2": "var(--color3)",\\
  "--palette-color3": "var(--color4)",\\
  "--palette-color4": "var(--color5)",\\
  "--palette-color5": "var(--color6)",\\
  "--palette-color6": "var(--color7)",\\
  "--palette-color7": "var(--color5_light)",\\
  "--palette-color8": "var(--color4_dark)",\\
\\
  "--design-option-color1": "255, 255, 255",\\
  "--design-option-color2": "248, 247, 244",\\
  "--design-option-color3": "241, 238, 230",\\
  "--design-option-color4": "214, 213, 209",\\
  "--design-option-color5": "102, 102, 102",\\
  "--design-option-color6": "51, 51, 51",\\
  "--design-option-color7": "2, 12, 28",\\
  "--design-option-color5_light": "22, 62, 229",\\
  "--design-option-color4_dark": "17, 47, 167",\\
\\
  "--c1": "var(--design-option-color1)",\\
  "--c2": "var(--design-option-color2)",\\
  "--c3": "var(--design-option-color3)",\\
  "--c4": "var(--design-option-color4)",\\
  "--c5": "var(--design-option-color5)",\\
  "--c6": "var(--design-option-color6)",\\
  "--c7": "var(--design-option-color7)",\\
  "--c8": "var(--design-option-color5_light)",\\
  "--c9": "var(--design-option-color4_dark)",\\
  \\
  "--widget-container--fillcolor": "var(--palette-color1)",\\
\\
  "--font1": "Georgia",\\
  "--font2": "Arial",\\
  "--text-style-unset": "none",\\
\\
  "--text-heading-1--fontSize--desktop": "120px",\\
  "--text-heading-1--fontSize--tablet": "100px",\\
  "--text-heading-1--fontSize--mobile": "80px",\\
  "--text-heading-1--fontFamily": "var(--font1)",\\
  "--text-heading-1--fontWeight": "normal",\\
  "--text-heading-1--fontType": "regular",\\
  "--text-heading-1--fontStyle": "normal",\\
  "--text-heading-1--fontStretch": "normal",\\
  "--text-heading-1--lineHeight": "1.07",\\
  "--text-heading-1--marginLeft": "0px",\\
  "--text-heading-1--color": "var(--palette-color6)",\\
  "--text-heading-1--borderBottomStyle": "none",\\
  "--text-heading-1--textDecoration": "none",\\
  "--text-heading-1--letterSpacing": "-0.01",\\
  "--text-heading-1--textTransform": "none",\\
  "--text-heading-1--stroke": "var(--palette-color2)",\\
  "--text-heading-1--textAlign": "left",\\
  "--text-heading-1--justifyContent": "flex-start",\\
  "--text-heading-1--marginTop": "auto",\\
  "--text-heading-1--marginBottom": "0",\\
  "--text-heading-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-2--fontSize--desktop": "80px",\\
  "--text-heading-2--fontSize--tablet": "72px",\\
  "--text-heading-2--fontSize--mobile": "60px",\\
  "--text-heading-2--fontFamily": "var(--font1)",\\
  "--text-heading-2--fontWeight": "normal",\\
  "--text-heading-2--fontType": "regular",\\
  "--text-heading-2--fontStyle": "normal",\\
  "--text-heading-2--fontStretch": "normal",\\
  "--text-heading-2--lineHeight": "1.1",\\
  "--text-heading-2--marginLeft": "0px",\\
  "--text-heading-2--color": "var(--palette-color6)",\\
  "--text-heading-2--borderBottomStyle": "none",\\
  "--text-heading-2--textDecoration": "none",\\
  "--text-heading-2--letterSpacing": "-0.04",\\
  "--text-heading-2--textTransform": "none",\\
  "--text-heading-2--stroke": "var(--palette-color2)",\\
  "--text-heading-2--textAlign": "left",\\
  "--text-heading-2--justifyContent": "flex-start",\\
  "--text-heading-2--marginTop": "auto",\\
  "--text-heading-2--marginBottom": "0",\\
  "--text-heading-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-3--fontSize--desktop": "60px",\\
  "--text-heading-3--fontSize--tablet": "52px",\\
  "--text-heading-3--fontSize--mobile": "44px",\\
  "--text-heading-3--fontFamily": "var(--font1)",\\
  "--text-heading-3--fontWeight": "normal",\\
  "--text-heading-3--fontType": "regular",\\
  "--text-heading-3--fontStyle": "normal",\\
  "--text-heading-3--fontStretch": "normal",\\
  "--text-heading-3--lineHeight": "1.1",\\
  "--text-heading-3--marginLeft": "0px",\\
  "--text-heading-3--color": "var(--palette-color6)",\\
  "--text-heading-3--borderBottomStyle": "none",\\
  "--text-heading-3--textDecoration": "none",\\
  "--text-heading-3--letterSpacing": "0.03",\\
  "--text-heading-3--textTransform": "none",\\
  "--text-heading-3--stroke": "var(--palette-color2)",\\
  "--text-heading-3--textAlign": "left",\\
  "--text-heading-3--justifyContent": "flex-start",\\
  "--text-heading-3--marginTop": "auto",\\
  "--text-heading-3--marginBottom": "0",\\
  "--text-heading-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-4--fontSize--desktop": "52px",\\
  "--text-heading-4--fontSize--tablet": "40px",\\
  "--text-heading-4--fontSize--mobile": "32px",\\
  "--text-heading-4--fontFamily": "var(--font1)",\\
  "--text-heading-4--fontWeight": "normal",\\
  "--text-heading-4--fontType": "regular",\\
  "--text-heading-4--fontStyle": "normal",\\
  "--text-heading-4--fontStretch": "normal",\\
  "--text-heading-4--lineHeight": "1.15",\\
  "--text-heading-4--marginLeft": "0px",\\
  "--text-heading-4--color": "var(--palette-color6)",\\
  "--text-heading-4--borderBottomStyle": "none",\\
  "--text-heading-4--textDecoration": "none",\\
  "--text-heading-4--letterSpacing": "0.10",\\
  "--text-heading-4--textTransform": "uppercase",\\
  "--text-heading-4--stroke": "var(--palette-color2)",\\
  "--text-heading-4--textAlign": "left",\\
  "--text-heading-4--justifyContent": "flex-start",\\
  "--text-heading-4--marginTop": "auto",\\
  "--text-heading-4--marginBottom": "0",\\
  "--text-heading-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-5--fontSize--desktop": "40px",\\
  "--text-heading-5--fontSize--tablet": "32px",\\
  "--text-heading-5--fontSize--mobile": "28px",\\
  "--text-heading-5--fontFamily": "var(--font1)",\\
  "--text-heading-5--fontWeight": "normal",\\
  "--text-heading-5--fontType": "regular",\\
  "--text-heading-5--fontStyle": "normal",\\
  "--text-heading-5--fontStretch": "normal",\\
  "--text-heading-5--lineHeight": "1.2",\\
  "--text-heading-5--marginLeft": "0px",\\
  "--text-heading-5--color": "var(--palette-color6)",\\
  "--text-heading-5--borderBottomStyle": "none",\\
  "--text-heading-5--textDecoration": "none",\\
  "--text-heading-5--letterSpacing": "0",\\
  "--text-heading-5--textTransform": "none",\\
  "--text-heading-5--stroke": "var(--palette-color2)",\\
  "--text-heading-5--textAlign": "left",\\
  "--text-heading-5--justifyContent": "flex-start",\\
  "--text-heading-5--marginTop": "auto",\\
  "--text-heading-5--marginBottom": "0",\\
  "--text-heading-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-6--fontSize--desktop": "36px",\\
  "--text-heading-6--fontSize--tablet": "28px",\\
  "--text-heading-6--fontSize--mobile": "24px",\\
  "--text-heading-6--fontFamily": "var(--font2)",\\
  "--text-heading-6--fontWeight": "normal",\\
  "--text-heading-6--fontType": "regular",\\
  "--text-heading-6--fontStyle": "normal",\\
  "--text-heading-6--fontStretch": "normal",\\
  "--text-heading-6--lineHeight": "1.2",\\
  "--text-heading-6--marginLeft": "0px",\\
  "--text-heading-6--color": "var(--palette-color6)",\\
  "--text-heading-6--borderBottomStyle": "none",\\
  "--text-heading-6--textDecoration": "none",\\
  "--text-heading-6--letterSpacing": "0",\\
  "--text-heading-6--textTransform": "none",\\
  "--text-heading-6--stroke": "var(--palette-color2)",\\
  "--text-heading-6--textAlign": "left",\\
  "--text-heading-6--justifyContent": "flex-start",\\
  "--text-heading-6--marginTop": "auto",\\
  "--text-heading-6--marginBottom": "0",\\
  "--text-heading-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-7--fontSize--desktop": "20px",\\
  "--text-heading-7--fontSize--tablet": "20px",\\
  "--text-heading-7--fontSize--mobile": "20px",\\
  "--text-heading-7--fontFamily": "var(--font1)",\\
  "--text-heading-7--fontWeight": "normal",\\
  "--text-heading-7--fontType": "regular",\\
  "--text-heading-7--fontStyle": "normal",\\
  "--text-heading-7--fontStretch": "normal",\\
  "--text-heading-7--lineHeight": "1.35",\\
  "--text-heading-7--marginLeft": "0px",\\
  "--text-heading-7--color": "var(--palette-color5)",\\
  "--text-heading-7--borderBottomStyle": "none",\\
  "--text-heading-7--textDecoration": "none",\\
  "--text-heading-7--letterSpacing": "0",\\
  "--text-heading-7--textTransform": "none",\\
  "--text-heading-7--stroke": "var(--palette-color2)",\\
  "--text-heading-7--textAlign": "left",\\
  "--text-heading-7--justifyContent": "flex-start",\\
  "--text-heading-7--marginTop": "auto",\\
  "--text-heading-7--marginBottom": "0",\\
  "--text-heading-7--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-7--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-7--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-7--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-8--fontSize--desktop": "72px",\\
  "--text-heading-8--fontSize--tablet": "48px",\\
  "--text-heading-8--fontSize--mobile": "32px",\\
  "--text-heading-8--fontFamily": "var(--font1)",\\
  "--text-heading-8--fontWeight": "normal",\\
  "--text-heading-8--fontType": "regular",\\
  "--text-heading-8--fontStyle": "normal",\\
  "--text-heading-8--fontStretch": "normal",\\
  "--text-heading-8--lineHeight": "1.35",\\
  "--text-heading-8--marginLeft": "0px",\\
  "--text-heading-8--color": "var(--palette-color5)",\\
  "--text-heading-8--borderBottomStyle": "none",\\
  "--text-heading-8--textDecoration": "none",\\
  "--text-heading-8--letterSpacing": "0",\\
  "--text-heading-8--textTransform": "none",\\
  "--text-heading-8--stroke": "var(--palette-color2)",\\
  "--text-heading-8--textAlign": "center",\\
  "--text-heading-8--justifyContent": "flex-start",\\
  "--text-heading-8--marginTop": "auto",\\
  "--text-heading-8--marginBottom": "0",\\
  "--text-heading-8--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-8--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-8--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-8--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-9--fontSize--desktop": "32px",\\
  "--text-heading-9--fontSize--tablet": "32px",\\
  "--text-heading-9--fontSize--mobile": "32px",\\
  "--text-heading-9--fontFamily": "var(--font1)",\\
  "--text-heading-9--fontWeight": "normal",\\
  "--text-heading-9--fontType": "regular",\\
  "--text-heading-9--fontStyle": "normal",\\
  "--text-heading-9--fontStretch": "normal",\\
  "--text-heading-9--lineHeight": "1.35",\\
  "--text-heading-9--marginLeft": "0px",\\
  "--text-heading-9--color": "var(--palette-color5)",\\
  "--text-heading-9--borderBottomStyle": "none",\\
  "--text-heading-9--textDecoration": "none",\\
  "--text-heading-9--letterSpacing": "0",\\
  "--text-heading-9--textTransform": "none",\\
  "--text-heading-9--stroke": "var(--palette-color2)",\\
  "--text-heading-9--textAlign": "center",\\
  "--text-heading-9--justifyContent": "flex-start",\\
  "--text-heading-9--marginTop": "auto",\\
  "--text-heading-9--marginBottom": "0",\\
  "--text-heading-9--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-9--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-9--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-9--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-1--fontSize--desktop": "22px",\\
  "--text-body-1--fontSize--tablet": "20px",\\
  "--text-body-1--fontSize--mobile": "18px",\\
  "--text-body-1--fontFamily": "var(--font1)",\\
  "--text-body-1--fontWeight": "normal",\\
  "--text-body-1--fontType": "regular",\\
  "--text-body-1--fontStyle": "normal",\\
  "--text-body-1--fontStretch": "normal",\\
  "--text-body-1--lineHeight": "1.3",\\
  "--text-body-1--marginLeft": "0px",\\
  "--text-body-1--color": "var(--palette-color5)",\\
  "--text-body-1--borderBottomStyle": "none",\\
  "--text-body-1--textDecoration": "none",\\
  "--text-body-1--letterSpacing": "0",\\
  "--text-body-1--textTransform": "none",\\
  "--text-body-1--stroke": "var(--palette-color2)",\\
  "--text-body-1--textAlign": "left",\\
  "--text-body-1--justifyContent": "flex-start",\\
  "--text-body-1--marginTop": "auto",\\
  "--text-body-1--marginBottom": "0",\\
  "--text-body-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-2--fontSize--desktop": "22px",\\
  "--text-body-2--fontSize--tablet": "20px",\\
  "--text-body-2--fontSize--mobile": "18px",\\
  "--text-body-2--fontFamily": "var(--font2)",\\
  "--text-body-2--fontWeight": "normal",\\
  "--text-body-2--fontType": "regular",\\
  "--text-body-2--fontStyle": "normal",\\
  "--text-body-2--fontStretch": "normal",\\
  "--text-body-2--lineHeight": "1.3",\\
  "--text-body-2--marginLeft": "0px",\\
  "--text-body-2--color": "var(--palette-color4)",\\
  "--text-body-2--borderBottomStyle": "none",\\
  "--text-body-2--textDecoration": "none",\\
  "--text-body-2--letterSpacing": "0.03",\\
  "--text-body-2--textTransform": "none",\\
  "--text-body-2--Stroke": "var(--palette-color2)",\\
  "--text-body-2--textAlign": "left",\\
  "--text-body-2--justifyContent": "flex-start",\\
  "--text-body-2--marginTop": "auto",\\
  "--text-body-2--marginBottom": "0",\\
  "--text-body-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-3--fontSize--desktop": "18px",\\
  "--text-body-3--fontSize--tablet": "16px",\\
  "--text-body-3--fontSize--mobile": "16px",\\
  "--text-body-3--fontFamily": "var(--font1)",\\
  "--text-body-3--fontWeight": "normal",\\
  "--text-body-3--fontType": "regular",\\
  "--text-body-3--fontStyle": "normal",\\
  "--text-body-3--fontStretch": "normal",\\
  "--text-body-3--lineHeight": "1.35",\\
  "--text-body-3--marginLeft": "0px",\\
  "--text-body-3--color": "var(--palette-color4)",\\
  "--text-body-3--borderBottomStyle": "none",\\
  "--text-body-3--textDecoration": "none",\\
  "--text-body-3--letterSpacing": "0",\\
  "--text-body-3--textTransform": "none",\\
  "--text-body-3--Stroke": "var(--palette-color2)",\\
  "--text-body-3--textAlign": "left",\\
  "--text-body-3--justifyContent": "flex-start",\\
  "--text-body-3--marginTop": "auto",\\
  "--text-body-3--marginBottom": "0",\\
  "--text-body-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-4--fontSize--desktop": "18px",\\
  "--text-body-4--fontSize--tablet": "16px",\\
  "--text-body-4--fontSize--mobile": "16px",\\
  "--text-body-4--fontFamily": "var(--font2)",\\
  "--text-body-4--fontWeight": "normal",\\
  "--text-body-4--fontType": "regular",\\
  "--text-body-4--fontStyle": "normal",\\
  "--text-body-4--fontStretch": "normal",\\
  "--text-body-4--lineHeight": "1.35",\\
  "--text-body-4--marginLeft": "0px",\\
  "--text-body-4--color": "var(--palette-color4)",\\
  "--text-body-4--borderBottomStyle": "none",\\
  "--text-body-4--textDecoration": "none",\\
  "--text-body-4--letterSpacing": "0",\\
  "--text-body-4--textTransform": "none",\\
  "--text-body-4--Stroke": "var(--palette-color2)",\\
  "--text-body-4--textAlign": "left",\\
  "--text-body-4--justifyContent": "flex-start",\\
  "--text-body-4--marginTop": "auto",\\
  "--text-body-4--marginBottom": "0",\\
  "--text-body-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-5--fontSize--desktop": "18px",\\
  "--text-body-5--fontSize--tablet": "16px",\\
  "--text-body-5--fontSize--mobile": "16px",\\
  "--text-body-5--fontFamily": "var(--font1)",\\
  "--text-body-5--fontWeight": "normal",\\
  "--text-body-5--fontType": "italic",\\
  "--text-body-5--fontStyle": "normal",\\
  "--text-body-5--fontStretch": "normal",\\
  "--text-body-5--lineHeight": "1.35",\\
  "--text-body-5--marginLeft": "0px",\\
  "--text-body-5--color": "var(--palette-color4)",\\
  "--text-body-5--borderBottomStyle": "none",\\
  "--text-body-5--textDecoration": "none",\\
  "--text-body-5--letterSpacing": "0",\\
  "--text-body-5--textTransform": "none",\\
  "--text-body-5--Stroke": "var(--palette-color2)",\\
  "--text-body-5--textAlign": "center",\\
  "--text-body-5--justifyContent": "flex-start",\\
  "--text-body-5--marginTop": "auto",\\
  "--text-body-5--marginBottom": "0",\\
  "--text-body-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-6--fontSize--desktop": "16px",\\
  "--text-body-6--fontSize--tablet": "14px",\\
  "--text-body-6--fontSize--mobile": "14px",\\
  "--text-body-6--fontFamily": "var(--font2)",\\
  "--text-body-6--fontWeight": "normal",\\
  "--text-body-6--fontType": "regular",\\
  "--text-body-6--fontStyle": "normal",\\
  "--text-body-6--fontStretch": "normal",\\
  "--text-body-6--lineHeight": "1.35",\\
  "--text-body-6--marginLeft": "0px",\\
  "--text-body-6--color": "var(--palette-color4)",\\
  "--text-body-6--borderBottomStyle": "none",\\
  "--text-body-6--textDecoration": "none",\\
  "--text-body-6--letterSpacing": "0",\\
  "--text-body-6--textTransform": "none",\\
  "--text-body-6--Stroke": "var(--palette-color2)",\\
  "--text-body-6--textAlign": "left",\\
  "--text-body-6--justifyContent": "flex-start",\\
  "--text-body-6--marginTop": "auto",\\
  "--text-body-6--marginBottom": "0",\\
  "--text-body-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-1--fontSize--desktop": "22px",\\
  "--text-component-1--fontSize--tablet": "20px",\\
  "--text-component-1--fontSize--mobile": "20px",\\
  "--text-component-1--fontFamily": "var(--font1)",\\
  "--text-component-1--fontWeight": "normal",\\
  "--text-component-1--fontType": "regular",\\
  "--text-component-1--fontStyle": "normal",\\
  "--text-component-1--fontStretch": "normal",\\
  "--text-component-1--lineHeight": "1.35",\\
  "--text-component-1--marginLeft": "0px",\\
  "--text-component-1--color": "var(--color6)",\\
  "--text-component-1--borderBottomStyle": "none",\\
  "--text-component-1--textDecoration": "none",\\
  "--text-component-1--letterSpacing": "0",\\
  "--text-component-1--textTransform": "none",\\
  "--text-component-1--stroke": "var(--palette-color2)",\\
  "--text-component-1--textAlign": "left",\\
  "--text-component-1--justifyContent": "flex-start",\\
  "--text-component-1--marginTop": "auto",\\
  "--text-component-1--marginBottom": "0",\\
  "--text-component-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-2--fontSize--desktop": "24px",\\
  "--text-component-2--fontSize--tablet": "20px",\\
  "--text-component-2--fontSize--mobile": "20px",\\
  "--text-component-2--fontFamily": "var(--font1)",\\
  "--text-component-2--fontWeight": "normal",\\
  "--text-component-2--fontType": "regular",\\
  "--text-component-2--fontStyle": "normal",\\
  "--text-component-2--fontStretch": "normal",\\
  "--text-component-2--lineHeight": "1.35",\\
  "--text-component-2--marginLeft": "0px",\\
  "--text-component-2--color": "var(--palette-color1)",\\
  "--text-component-2--borderBottomStyle": "none",\\
  "--text-component-2--textDecoration": "none",\\
  "--text-component-2--letterSpacing": "0.16",\\
  "--text-component-2--textTransform": "none",\\
  "--text-component-2--stroke": "var(--palette-color2)",\\
  "--text-component-2--textAlign": "left",\\
  "--text-component-2--justifyContent": "flex-start",\\
  "--text-component-2--marginTop": "auto",\\
  "--text-component-2--marginBottom": "0",\\
  "--text-component-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-3--fontSize--desktop": "14px",\\
  "--text-component-3--fontSize--tablet": "14px",\\
  "--text-component-3--fontSize--mobile": "14px",\\
  "--text-component-3--fontFamily": "var(--font1)",\\
  "--text-component-3--fontWeight": "normal",\\
  "--text-component-3--fontType": "regular",\\
  "--text-component-3--fontStyle": "normal",\\
  "--text-component-3--fontStretch": "normal",\\
  "--text-component-3--lineHeight": "1.35",\\
  "--text-component-3--marginLeft": "0px",\\
  "--text-component-3--color": "var(--palette-color6)",\\
  "--text-component-3--borderBottomStyle": "none",\\
  "--text-component-3--textDecoration": "none",\\
  "--text-component-3--letterSpacing": "0.2",\\
  "--text-component-3--textTransform": "uppercase",\\
  "--text-component-3--stroke": "var(--palette-color2)",\\
  "--text-component-3--textAlign": "center",\\
  "--text-component-3--justifyContent": "flex-start",\\
  "--text-component-3--marginTop": "auto",\\
  "--text-component-3--marginBottom": "0",\\
  "--text-component-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-4--fontSize--desktop": "22px",\\
  "--text-component-4--fontSize--tablet": "20px",\\
  "--text-component-4--fontSize--mobile": "20px",\\
  "--text-component-4--fontFamily": "var(--font1)",\\
  "--text-component-4--fontWeight": "normal",\\
  "--text-component-4--fontType": "regular",\\
  "--text-component-4--fontStyle": "normal",\\
  "--text-component-4--fontStretch": "normal",\\
  "--text-component-4--lineHeight": "1.35",\\
  "--text-component-4--marginLeft": "0px",\\
  "--text-component-4--color": "var(--color6)",\\
  "--text-component-4--borderBottomStyle": "none",\\
  "--text-component-4--textDecoration": "none",\\
  "--text-component-4--letterSpacing": "0.02",\\
  "--text-component-4--textTransform": "none",\\
  "--text-component-4--stroke": "var(--palette-color2)",\\
  "--text-component-4--textAlign": "left",\\
  "--text-component-4--justifyContent": "flex-start",\\
  "--text-component-4--marginTop": "auto",\\
  "--text-component-4--marginBottom": "0",\\
  "--text-component-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-1--fontSize--desktop": "36px",\\
  "--text-subheading-1--fontSize--tablet": "32px",\\
  "--text-subheading-1--fontSize--mobile": "28px",\\
  "--text-subheading-1--fontFamily": "var(--font2)",\\
  "--text-subheading-1--fontWeight": "normal",\\
  "--text-subheading-1--fontType": "regular",\\
  "--text-subheading-1--fontStyle": "normal",\\
  "--text-subheading-1--fontStretch": "normal",\\
  "--text-subheading-1--lineHeight": "1.1",\\
  "--text-subheading-1--marginLeft": "0px",\\
  "--text-subheading-1--color": "var(--palette-color6)",\\
  "--text-subheading-1--borderBottomStyle": "none",\\
  "--text-subheading-1--textDecoration": "none",\\
  "--text-subheading-1--letterSpacing": "0.05",\\
  "--text-subheading-1--textTransform": "uppercase",\\
  "--text-subheading-1--stroke": "var(--palette-color2)",\\
  "--text-subheading-1--textAlign": "left",\\
  "--text-subheading-1--justifyContent": "flex-start",\\
  "--text-subheading-1--marginTop": "auto",\\
  "--text-subheading-1--marginBottom": "0",\\
  "--text-subheading-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-2--fontSize--desktop": "28px",\\
  "--text-subheading-2--fontSize--tablet": "24px",\\
  "--text-subheading-2--fontSize--mobile": "20px",\\
  "--text-subheading-2--fontFamily": "var(--font2)",\\
  "--text-subheading-2--fontWeight": "normal",\\
  "--text-subheading-2--fontType": "bold",\\
  "--text-subheading-2--fontStyle": "normal",\\
  "--text-subheading-2--fontStretch": "normal",\\
  "--text-subheading-2--lineHeight": "1.15",\\
  "--text-subheading-2--marginLeft": "0px",\\
  "--text-subheading-2--color": "var(--palette-color6)",\\
  "--text-subheading-2--borderBottomStyle": "none",\\
  "--text-subheading-2--textDecoration": "none",\\
  "--text-subheading-2--letterSpacing": "0.05",\\
  "--text-subheading-2--textTransform": "none",\\
  "--text-subheading-2--stroke": "var(--palette-color2)",\\
  "--text-subheading-2--textAlign": "left",\\
  "--text-subheading-2--justifyContent": "flex-start",\\
  "--text-subheading-2--marginTop": "auto",\\
  "--text-subheading-2--marginBottom": "0",\\
  "--text-subheading-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-3--fontSize--desktop": "26px",\\
  "--text-subheading-3--fontSize--tablet": "22px",\\
  "--text-subheading-3--fontSize--mobile": "18px",\\
  "--text-subheading-3--fontFamily": "var(--font2)",\\
  "--text-subheading-3--fontWeight": "normal",\\
  "--text-subheading-3--fontType": "regular",\\
  "--text-subheading-3--fontStyle": "normal",\\
  "--text-subheading-3--fontStretch": "normal",\\
  "--text-subheading-3--lineHeight": "1.15",\\
  "--text-subheading-3--marginLeft": "0px",\\
  "--text-subheading-3--color": "var(--palette-color6)",\\
  "--text-subheading-3--borderBottomStyle": "none",\\
  "--text-subheading-3--textDecoration": "none",\\
  "--text-subheading-3--letterSpacing": "0",\\
  "--text-subheading-3--textTransform": "none",\\
  "--text-subheading-3--stroke": "var(--palette-color2)",\\
  "--text-subheading-3--textAlign": "center",\\
  "--text-subheading-3--justifyContent": "flex-start",\\
  "--text-subheading-3--marginTop": "auto",\\
  "--text-subheading-3--marginBottom": "0",\\
  "--text-subheading-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-4--fontSize--desktop": "24px",\\
  "--text-subheading-4--fontSize--tablet": "20px",\\
  "--text-subheading-4--fontSize--mobile": "16px",\\
  "--text-subheading-4--fontFamily": "var(--font2)",\\
  "--text-subheading-4--fontWeight": "normal",\\
  "--text-subheading-4--fontType": "bold",\\
  "--text-subheading-4--fontStyle": "normal",\\
  "--text-subheading-4--fontStretch": "normal",\\
  "--text-subheading-4--lineHeight": "1.15",\\
  "--text-subheading-4--marginLeft": "0px",\\
  "--text-subheading-4--color": "var(--palette-color0)",\\
  "--text-subheading-4--borderBottomStyle": "none",\\
  "--text-subheading-4--textDecoration": "none",\\
  "--text-subheading-4--letterSpacing": "0.05",\\
  "--text-subheading-4--textTransform": "none",\\
  "--text-subheading-4--stroke": "var(--palette-color2)",\\
  "--text-subheading-4--textAlign": "left",\\
  "--text-subheading-4--justifyContent": "flex-start",\\
  "--text-subheading-4--marginTop": "auto",\\
  "--text-subheading-4--marginBottom": "0",\\
  "--text-subheading-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-5--fontSize--desktop": "24px",\\
  "--text-subheading-5--fontSize--tablet": "20px",\\
  "--text-subheading-5--fontSize--mobile": "16px",\\
  "--text-subheading-5--fontFamily": "var(--font1)",\\
  "--text-subheading-5--fontWeight": "normal",\\
  "--text-subheading-5--fontType": "bold",\\
  "--text-subheading-5--fontStyle": "normal",\\
  "--text-subheading-5--fontStretch": "normal",\\
  "--text-subheading-5--lineHeight": "1.15",\\
  "--text-subheading-5--marginLeft": "0px",\\
  "--text-subheading-5--color": "var(--palette-color5)",\\
  "--text-subheading-5--borderBottomStyle": "none",\\
  "--text-subheading-5--textDecoration": "none",\\
  "--text-subheading-5--letterSpacing": "-0.05",\\
  "--text-subheading-5--textTransform": "none",\\
  "--text-subheading-5--stroke": "var(--palette-color2)",\\
  "--text-subheading-5--textAlign": "left",\\
  "--text-subheading-5--justifyContent": "flex-start",\\
  "--text-subheading-5--marginTop": "auto",\\
  "--text-subheading-5--marginBottom": "0",\\
  "--text-subheading-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-6--fontSize--desktop": "18px",\\
  "--text-subheading-6--fontSize--tablet": "16px",\\
  "--text-subheading-6--fontSize--mobile": "14px",\\
  "--text-subheading-6--fontFamily": "var(--font2)",\\
  "--text-subheading-6--fontWeight": "normal",\\
  "--text-subheading-6--fontType": "bold",\\
  "--text-subheading-6--fontStyle": "normal",\\
  "--text-subheading-6--fontStretch": "normal",\\
  "--text-subheading-6--lineHeight": "1.25",\\
  "--text-subheading-6--marginLeft": "0px",\\
  "--text-subheading-6--color": "var(--palette-color5)",\\
  "--text-subheading-6--borderBottomStyle": "none",\\
  "--text-subheading-6--textDecoration": "none",\\
  "--text-subheading-6--letterSpacing": "0",\\
  "--text-subheading-6--textTransform": "none",\\
  "--text-subheading-6--stroke": "var(--palette-color2)",\\
  "--text-subheading-6--textAlign": "left",\\
  "--text-subheading-6--justifyContent": "flex-start",\\
  "--text-subheading-6--marginTop": "auto",\\
  "--text-subheading-6--marginBottom": "0",\\
  "--text-subheading-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-1--fontSize--desktop": "20px",\\
  "--text-detail-1--fontSize--tablet": "18px",\\
  "--text-detail-1--fontSize--mobile": "16px",\\
  "--text-detail-1--fontFamily": "var(--font2)",\\
  "--text-detail-1--fontWeight": "normal",\\
  "--text-detail-1--fontType": "regular",\\
  "--text-detail-1--fontStyle": "normal",\\
  "--text-detail-1--fontStretch": "normal",\\
  "--text-detail-1--lineHeight": "1.2",\\
  "--text-detail-1--marginLeft": "0px",\\
  "--text-detail-1--color": "var(--palette-color6)",\\
  "--text-detail-1--borderBottomStyle": "none",\\
  "--text-detail-1--textDecoration": "none",\\
  "--text-detail-1--letterSpacing": "0",\\
  "--text-detail-1--textTransform": "uppercase",\\
  "--text-detail-1--stroke": "var(--palette-color5)",\\
  "--text-detail-1--textAlign": "left",\\
  "--text-detail-1--justifyContent": "flex-start",\\
  "--text-detail-1--marginTop": "auto",\\
  "--text-detail-1--marginBottom": "0",\\
  "--text-detail-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-2--fontSize--desktop": "16px",\\
  "--text-detail-2--fontSize--tablet": "14px",\\
  "--text-detail-2--fontSize--mobile": "12px",\\
  "--text-detail-2--fontFamily": "var(--font2)",\\
  "--text-detail-2--fontWeight": "normal",\\
  "--text-detail-2--fontType": "bold",\\
  "--text-detail-2--fontStyle": "normal",\\
  "--text-detail-2--fontStretch": "normal",\\
  "--text-detail-2--lineHeight": "1.3",\\
  "--text-detail-2--marginLeft": "0px",\\
  "--text-detail-2--color": "var(--palette-color6)",\\
  "--text-detail-2--borderBottomStyle": "none",\\
  "--text-detail-2--textDecoration": "none",\\
  "--text-detail-2--letterSpacing": "0",\\
  "--text-detail-2--textTransform": "uppercase",\\
  "--text-detail-2--stroke": "var(--palette-color2)",\\
  "--text-detail-2--textAlign": "left",\\
  "--text-detail-2--justifyContent": "flex-start",\\
  "--text-detail-2--marginTop": "auto",\\
  "--text-detail-2--marginBottom": "0",\\
  "--text-detail-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-3--fontSize--desktop": "16px",\\
  "--text-detail-3--fontSize--tablet": "14px",\\
  "--text-detail-3--fontSize--mobile": "12px",\\
  "--text-detail-3--fontFamily": "var(--font2)",\\
  "--text-detail-3--fontWeight": "normal",\\
  "--text-detail-3--fontType": "regular",\\
  "--text-detail-3--fontStyle": "normal",\\
  "--text-detail-3--fontStretch": "normal",\\
  "--text-detail-3--lineHeight": "1.35",\\
  "--text-detail-3--marginLeft": "0px",\\
  "--text-detail-3--color": "var(--palette-color4)",\\
  "--text-detail-3--borderBottomStyle": "none",\\
  "--text-detail-3--textDecoration": "none",\\
  "--text-detail-3--letterSpacing": "0.2",\\
  "--text-detail-3--textTransform": "uppercase",\\
  "--text-detail-3--stroke": "var(--palette-color2)",\\
  "--text-detail-3--textAlign": "left",\\
  "--text-detail-3--justifyContent": "flex-start",\\
  "--text-detail-3--marginTop": "auto",\\
  "--text-detail-3--marginBottom": "0",\\
  "--text-detail-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-4--fontSize--desktop": "22px",\\
  "--text-detail-4--fontSize--tablet": "20px",\\
  "--text-detail-4--fontSize--mobile": "20px",\\
  "--text-detail-4--fontFamily": "var(--font1)",\\
  "--text-detail-4--fontWeight": "normal",\\
  "--text-detail-4--fontType": "regular",\\
  "--text-detail-4--fontStyle": "normal",\\
  "--text-detail-4--fontStretch": "normal",\\
  "--text-detail-4--lineHeight": "1.35",\\
  "--text-detail-4--marginLeft": "0px",\\
  "--text-detail-4--color": "var(--palette-color5)",\\
  "--text-detail-4--borderBottomStyle": "none",\\
  "--text-detail-4--textDecoration": "none",\\
  "--text-detail-4--letterSpacing": "0",\\
  "--text-detail-4--textTransform": "none",\\
  "--text-detail-4--stroke": "var(--palette-color2)",\\
  "--text-detail-4--textAlign": "center",\\
  "--text-detail-4--justifyContent": "flex-start",\\
  "--text-detail-4--marginTop": "auto",\\
  "--text-detail-4--marginBottom": "0",\\
  "--text-detail-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-1--fontSize--desktop": "36px",\\
  "--text-variable-1--fontSize--tablet": "32px",\\
  "--text-variable-1--fontSize--mobile": "30px",\\
  "--text-variable-1--fontFamily": "var(--font2)",\\
  "--text-variable-1--fontWeight": "normal",\\
  "--text-variable-1--fontType": "bold",\\
  "--text-variable-1--fontStyle": "normal",\\
  "--text-variable-1--fontStretch": "normal",\\
  "--text-variable-1--lineHeight": "1.2",\\
  "--text-variable-1--marginLeft": "0px",\\
  "--text-variable-1--color": "var(--palette-color7)",\\
  "--text-variable-1--borderBottomStyle": "none",\\
  "--text-variable-1--textDecoration": "none",\\
  "--text-variable-1--letterSpacing": "0.02",\\
  "--text-variable-1--textTransform": "none",\\
  "--text-variable-1--stroke": "var(--palette-color2)",\\
  "--text-variable-1--textAlign": "left",\\
  "--text-variable-1--justifyContent": "flex-start",\\
  "--text-variable-1--marginTop": "auto",\\
  "--text-variable-1--marginBottom": "0",\\
  "--text-variable-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-2--fontSize--desktop": "24px",\\
  "--text-variable-2--fontSize--tablet": "22px",\\
  "--text-variable-2--fontSize--mobile": "20px",\\
  "--text-variable-2--fontFamily": "var(--font2)",\\
  "--text-variable-2--fontWeight": "normal",\\
  "--text-variable-2--fontType": "bold",\\
  "--text-variable-2--fontStyle": "normal",\\
  "--text-variable-2--fontStretch": "normal",\\
  "--text-variable-2--lineHeight": "1.15",\\
  "--text-variable-2--marginLeft": "0px",\\
  "--text-variable-2--color": "var(--palette-color6)",\\
  "--text-variable-2--borderBottomStyle": "none",\\
  "--text-variable-2--textDecoration": "none",\\
  "--text-variable-2--letterSpacing": "0",\\
  "--text-variable-2--textTransform": "none",\\
  "--text-variable-2--stroke": "var(--palette-color2)",\\
  "--text-variable-2--textAlign": "left",\\
  "--text-variable-2--justifyContent": "flex-start",\\
  "--text-variable-2--marginTop": "auto",\\
  "--text-variable-2--marginBottom": "0",\\
  "--text-variable-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-3--fontSize--desktop": "20px",\\
  "--text-variable-3--fontSize--tablet": "18px",\\
  "--text-variable-3--fontSize--mobile": "16px",\\
  "--text-variable-3--fontFamily": "var(--font1)",\\
  "--text-variable-3--fontWeight": "normal",\\
  "--text-variable-3--fontType": "bold",\\
  "--text-variable-3--fontStyle": "normal",\\
  "--text-variable-3--fontStretch": "normal",\\
  "--text-variable-3--lineHeight": "1.2",\\
  "--text-variable-3--marginLeft": "0px",\\
  "--text-variable-3--color": "var(--palette-color6)",\\
  "--text-variable-3--borderBottomStyle": "none",\\
  "--text-variable-3--textDecoration": "none",\\
  "--text-variable-3--letterSpacing": "0",\\
  "--text-variable-3--textTransform": "none",\\
  "--text-variable-3--stroke": "var(--palette-color2)",\\
  "--text-variable-3--textAlign": "left",\\
  "--text-variable-3--justifyContent": "flex-start",\\
  "--text-variable-3--marginTop": "auto",\\
  "--text-variable-3--marginBottom": "0",\\
  "--text-variable-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-4--fontSize--desktop": "16px",\\
  "--text-variable-4--fontSize--tablet": "14px",\\
  "--text-variable-4--fontSize--mobile": "12px",\\
  "--text-variable-4--fontFamily": "var(--font2)",\\
  "--text-variable-4--fontWeight": "normal",\\
  "--text-variable-4--fontType": "bold",\\
  "--text-variable-4--fontStyle": "normal",\\
  "--text-variable-4--fontStretch": "normal",\\
  "--text-variable-4--lineHeight": "1.3",\\
  "--text-variable-4--marginLeft": "0px",\\
  "--text-variable-4--color": "var(--palette-color6)",\\
  "--text-variable-4--borderBottomStyle": "none",\\
  "--text-variable-4--textDecoration": "none",\\
  "--text-variable-4--letterSpacing": "0.02",\\
  "--text-variable-4--textTransform": "none",\\
  "--text-variable-4--stroke": "var(--palette-color2)",\\
  "--text-variable-4--textAlign": "left",\\
  "--text-variable-4--justifyContent": "flex-start",\\
  "--text-variable-4--marginTop": "auto",\\
  "--text-variable-4--marginBottom": "0",\\
  "--text-variable-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-question-1--fontSize--desktop": "48px",\\
  "--text-question-1--fontSize--tablet": "20px",\\
  "--text-question-1--fontSize--mobile": "20px",\\
  "--text-question-1--fontFamily": "var(--font1)",\\
  "--text-question-1--fontWeight": "normal",\\
  "--text-question-1--fontType": "regular",\\
  "--text-question-1--fontStyle": "normal",\\
  "--text-question-1--fontStretch": "normal",\\
  "--text-question-1--lineHeight": "1.35",\\
  "--text-question-1--marginLeft": "0px",\\
  "--text-question-1--color": "var(--palette-color5)",\\
  "--text-question-1--borderBottomStyle": "none",\\
  "--text-question-1--textDecoration": "none",\\
  "--text-question-1--letterSpacing": "0",\\
  "--text-question-1--textTransform": "none",\\
  "--text-question-1--stroke": "var(--palette-color2)",\\
  "--text-question-1--textAlign": "left",\\
  "--text-question-1--justifyContent": "flex-start",\\
  "--text-question-1--marginTop": "auto",\\
  "--text-question-1--marginBottom": "0",\\
  "--text-question-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-question-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-question-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-question-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-question-2--fontSize--desktop": "24px",\\
  "--text-question-2--fontSize--tablet": "20px",\\
  "--text-question-2--fontSize--mobile": "20px",\\
  "--text-question-2--fontFamily": "var(--font1)",\\
  "--text-question-2--fontWeight": "normal",\\
  "--text-question-2--fontType": "bold",\\
  "--text-question-2--fontStyle": "normal",\\
  "--text-question-2--fontStretch": "normal",\\
  "--text-question-2--lineHeight": "1.35",\\
  "--text-question-2--marginLeft": "0px",\\
  "--text-question-2--color": "var(--palette-color5)",\\
  "--text-question-2--borderBottomStyle": "none",\\
  "--text-question-2--textDecoration": "none",\\
  "--text-question-2--letterSpacing": "0",\\
  "--text-question-2--textTransform": "none",\\
  "--text-question-2--stroke": "var(--palette-color2)",\\
  "--text-question-2--textAlign": "left",\\
  "--text-question-2--justifyContent": "flex-start",\\
  "--text-question-2--marginTop": "auto",\\
  "--text-question-2--marginBottom": "0",\\
  "--text-question-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-question-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-question-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-question-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-1--fontSize--desktop": "16px",\\
  "--text-button-1--fontSize--tablet": "16px",\\
  "--text-button-1--fontSize--mobile": "16px",\\
  "--text-button-1--fontFamily": "var(--font2)",\\
  "--text-button-1--fontWeight": "normal",\\
  "--text-button-1--fontType": "regular",\\
  "--text-button-1--fontStyle": "normal",\\
  "--text-button-1--fontStretch": "normal",\\
  "--text-button-1--lineHeight": "1.25",\\
  "--text-button-1--marginLeft": "0px",\\
  "--text-button-1--color": "var(--palette-color7)",\\
  "--text-button-1--borderBottomStyle": "none",\\
  "--text-button-1--textDecoration": "none",\\
  "--text-button-1--letterSpacing": "0.12",\\
  "--text-button-1--textTransform": "uppercase",\\
  "--text-button-1--stroke": "var(--palette-color2)",\\
  "--text-button-1--textAlign": "center",\\
  "--text-button-1--justifyContent": "flex-start",\\
  "--text-button-1--marginTop": "auto",\\
  "--text-button-1--marginBottom": "0",\\
  "--text-button-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-2--fontSize--desktop": "16px",\\
  "--text-button-2--fontSize--tablet": "16px",\\
  "--text-button-2--fontSize--mobile": "16px",\\
  "--text-button-2--fontFamily": "var(--font2)",\\
  "--text-button-2--fontWeight": "normal",\\
  "--text-button-2--fontType": "regular",\\
  "--text-button-2--fontStyle": "normal",\\
  "--text-button-2--fontStretch": "normal",\\
  "--text-button-2--lineHeight": "1.25",\\
  "--text-button-2--marginLeft": "0px",\\
  "--text-button-2--color": "var(--palette-color0)",\\
  "--text-button-2--borderBottomStyle": "none",\\
  "--text-button-2--textDecoration": "none",\\
  "--text-button-2--letterSpacing": "0.12",\\
  "--text-button-2--textTransform": "uppercase",\\
  "--text-button-2--stroke": "var(--palette-color2)",\\
  "--text-button-2--textAlign": "center",\\
  "--text-button-2--justifyContent": "flex-start",\\
  "--text-button-2--marginTop": "auto",\\
  "--text-button-2--marginBottom": "0",\\
  "--text-button-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-3--fontSize--desktop": "16px",\\
  "--text-button-3--fontSize--tablet": "16px",\\
  "--text-button-3--fontSize--mobile": "16px",\\
  "--text-button-3--fontFamily": "var(--font2)",\\
  "--text-button-3--fontWeight": "normal",\\
  "--text-button-3--fontType": "regular",\\
  "--text-button-3--fontStyle": "normal",\\
  "--text-button-3--fontStretch": "normal",\\
  "--text-button-3--lineHeight": "1.25",\\
  "--text-button-3--marginLeft": "0px",\\
  "--text-button-3--color": "var(--palette-color5)",\\
  "--text-button-3--borderBottomStyle": "none",\\
  "--text-button-3--textDecoration": "none",\\
  "--text-button-3--letterSpacing": "0.12",\\
  "--text-button-3--textTransform": "uppercase",\\
  "--text-button-3--stroke": "var(--palette-color2)",\\
  "--text-button-3--textAlign": "center",\\
  "--text-button-3--justifyContent": "flex-start",\\
  "--text-button-3--marginTop": "auto",\\
  "--text-button-3--marginBottom": "0",\\
  "--text-button-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-4--fontSize--desktop": "16px",\\
  "--text-button-4--fontSize--tablet": "16px",\\
  "--text-button-4--fontSize--mobile": "16px",\\
  "--text-button-4--fontFamily": "var(--font2)",\\
  "--text-button-4--fontWeight": "normal",\\
  "--text-button-4--fontType": "regular",\\
  "--text-button-4--fontStyle": "normal",\\
  "--text-button-4--fontStretch": "normal",\\
  "--text-button-4--lineHeight": "1.25",\\
  "--text-button-4--marginLeft": "0px",\\
  "--text-button-4--color": "var(--palette-color4)",\\
  "--text-button-4--borderBottomStyle": "none",\\
  "--text-button-4--textDecoration": "none",\\
  "--text-button-4--letterSpacing": "0.12",\\
  "--text-button-4--textTransform": "uppercase",\\
  "--text-button-4--stroke": "var(--palette-color2)",\\
  "--text-button-4--textAlign": "center",\\
  "--text-button-4--justifyContent": "flex-start",\\
  "--text-button-4--marginTop": "auto",\\
  "--text-button-4--marginBottom": "0",\\
  "--text-button-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-1--fontSize--desktop": "18px",\\
  "--text-uic-1--fontSize--tablet": "18px",\\
  "--text-uic-1--fontSize--mobile": "18px",\\
  "--text-uic-1--fontFamily": "var(--font1)",\\
  "--text-uic-1--fontWeight": "normal",\\
  "--text-uic-1--fontType": "italic",\\
  "--text-uic-1--fontStyle": "normal",\\
  "--text-uic-1--fontStretch": "normal",\\
  "--text-uic-1--lineHeight": "1.35",\\
  "--text-uic-1--marginLeft": "0px",\\
  "--text-uic-1--color": "var(--palette-color4)",\\
  "--text-uic-1--borderBottomStyle": "none",\\
  "--text-uic-1--textDecoration": "none",\\
  "--text-uic-1--letterSpacing": "0",\\
  "--text-uic-1--textTransform": "none",\\
  "--text-uic-1--stroke": "var(--palette-color2)",\\
  "--text-uic-1--textAlign": "left",\\
  "--text-uic-1--justifyContent": "flex-start",\\
  "--text-uic-1--marginTop": "auto",\\
  "--text-uic-1--marginBottom": "0",\\
  "--text-uic-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-2--fontSize--desktop": "18px",\\
  "--text-uic-2--fontSize--tablet": "18px",\\
  "--text-uic-2--fontSize--mobile": "18px",\\
  "--text-uic-2--fontFamily": "var(--font1)",\\
  "--text-uic-2--fontWeight": "normal",\\
  "--text-uic-2--fontType": "italic",\\
  "--text-uic-2--fontStyle": "normal",\\
  "--text-uic-2--fontStretch": "normal",\\
  "--text-uic-2--lineHeight": "1.35",\\
  "--text-uic-2--marginLeft": "0px",\\
  "--text-uic-2--color": "var(--palette-color1)",\\
  "--text-uic-2--borderBottomStyle": "none",\\
  "--text-uic-2--textDecoration": "none",\\
  "--text-uic-2--letterSpacing": "0",\\
  "--text-uic-2--textTransform": "none",\\
  "--text-uic-2--stroke": "var(--palette-color2)",\\
  "--text-uic-2--textAlign": "left",\\
  "--text-uic-2--justifyContent": "flex-start",\\
  "--text-uic-2--marginTop": "auto",\\
  "--text-uic-2--marginBottom": "0",\\
  "--text-uic-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-3--fontSize--desktop": "22px",\\
  "--text-uic-3--fontSize--tablet": "22px",\\
  "--text-uic-3--fontSize--mobile": "22px",\\
  "--text-uic-3--fontFamily": "var(--font1)",\\
  "--text-uic-3--fontWeight": "normal",\\
  "--text-uic-3--fontType": "regular",\\
  "--text-uic-3--fontStyle": "normal",\\
  "--text-uic-3--fontStretch": "normal",\\
  "--text-uic-3--lineHeight": "1.25",\\
  "--text-uic-3--marginLeft": "0px",\\
  "--text-uic-3--color": "var(--palette-color5)",\\
  "--text-uic-3--borderBottomStyle": "none",\\
  "--text-uic-3--textDecoration": "none",\\
  "--text-uic-3--letterSpacing": "0",\\
  "--text-uic-3--textTransform": "none",\\
  "--text-uic-3--stroke": "var(--palette-color2)",\\
  "--text-uic-3--textAlign": "left",\\
  "--text-uic-3--justifyContent": "flex-start",\\
  "--text-uic-3--marginTop": "auto",\\
  "--text-uic-3--marginBottom": "0",\\
  "--text-uic-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-4--fontSize--desktop": "22px",\\
  "--text-uic-4--fontSize--tablet": "22px",\\
  "--text-uic-4--fontSize--mobile": "22px",\\
  "--text-uic-4--fontFamily": "var(--font1)",\\
  "--text-uic-4--fontWeight": "normal",\\
  "--text-uic-4--fontType": "regular",\\
  "--text-uic-4--fontStyle": "normal",\\
  "--text-uic-4--fontStretch": "normal",\\
  "--text-uic-4--lineHeight": "1.25",\\
  "--text-uic-4--marginLeft": "0px",\\
  "--text-uic-4--color": "var(--palette-color4)",\\
  "--text-uic-4--borderBottomStyle": "none",\\
  "--text-uic-4--textDecoration": "none",\\
  "--text-uic-4--letterSpacing": "0",\\
  "--text-uic-4--textTransform": "none",\\
  "--text-uic-4--stroke": "var(--palette-color2)",\\
  "--text-uic-4--textAlign": "left",\\
  "--text-uic-4--justifyContent": "flex-start",\\
  "--text-uic-4--marginTop": "auto",\\
  "--text-uic-4--marginBottom": "0",\\
  "--text-uic-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-5--fontSize--desktop": "22px",\\
  "--text-uic-5--fontSize--tablet": "22px",\\
  "--text-uic-5--fontSize--mobile": "22px",\\
  "--text-uic-5--fontFamily": "var(--font1)",\\
  "--text-uic-5--fontWeight": "normal",\\
  "--text-uic-5--fontType": "regular",\\
  "--text-uic-5--fontStyle": "normal",\\
  "--text-uic-5--fontStretch": "normal",\\
  "--text-uic-5--lineHeight": "1.25",\\
  "--text-uic-5--marginLeft": "0px",\\
  "--text-uic-5--color": "var(--palette-color3)",\\
  "--text-uic-5--borderBottomStyle": "none",\\
  "--text-uic-5--textDecoration": "none",\\
  "--text-uic-5--letterSpacing": "0",\\
  "--text-uic-5--textTransform": "none",\\
  "--text-uic-5--stroke": "var(--palette-color2)",\\
  "--text-uic-5--textAlign": "left",\\
  "--text-uic-5--justifyContent": "flex-start",\\
  "--text-uic-5--marginTop": "auto",\\
  "--text-uic-5--marginBottom": "0",\\
  "--text-uic-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-6--fontSize--desktop": "16px",\\
  "--text-uic-6--fontSize--tablet": "16px",\\
  "--text-uic-6--fontSize--mobile": "16px",\\
  "--text-uic-6--fontFamily": "var(--font2)",\\
  "--text-uic-6--fontWeight": "normal",\\
  "--text-uic-6--fontType": "bold",\\
  "--text-uic-6--fontStyle": "normal",\\
  "--text-uic-6--fontStretch": "normal",\\
  "--text-uic-6--lineHeight": "1.5",\\
  "--text-uic-6--marginLeft": "0px",\\
  "--text-uic-6--color": "var(--palette-color7)",\\
  "--text-uic-6--borderBottomStyle": "none",\\
  "--text-uic-6--textDecoration": "none",\\
  "--text-uic-6--letterSpacing": "0.12",\\
  "--text-uic-6--textTransform": "none",\\
  "--text-uic-6--stroke": "var(--palette-color2)",\\
  "--text-uic-6--textAlign": "left",\\
  "--text-uic-6--justifyContent": "flex-start",\\
  "--text-uic-6--marginTop": "auto",\\
  "--text-uic-6--marginBottom": "0",\\
  "--text-uic-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-closedcaptions--fontSize--desktop": "24px",\\
  "--text-closedcaptions--fontSize--tablet": "24px",\\
  "--text-closedcaptions--fontSize--mobile": "24px",\\
  "--text-closedcaptions--fontFamily": "var(--font1)",\\
  "--text-closedcaptions--fontWeight": "normal",\\
  "--text-closedcaptions--fontType": "regular",\\
  "--text-closedcaptions--fontStyle": "normal",\\
  "--text-closedcaptions--fontStretch": "normal",\\
  "--text-closedcaptions--lineHeight": "1.35",\\
  "--text-closedcaptions--marginLeft": "0px",\\
  "--text-closedcaptions--color": "var(--white)",\\
  "--text-closedcaptions--borderBottomStyle": "none",\\
  "--text-closedcaptions--textDecoration": "none",\\
  "--text-closedcaptions--letterSpacing": "0",\\
  "--text-closedcaptions--textTransform": "none",\\
  "--text-closedcaptions--stroke": "var(--palette-color2)",\\
  "--text-closedcaptions--textAlign": "center",\\
  "--text-closedcaptions--justifyContent": "flex-start",\\
  "--text-closedcaptions--marginTop": "auto",\\
  "--text-closedcaptions--marginBottom": "0",\\
  "--text-closedcaptions--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-closedcaptions--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-closedcaptions--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-closedcaptions--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption--fontSize--desktop": "24px",\\
  "--text-caption--fontSize--tablet": "24px",\\
  "--text-caption--fontSize--mobile": "24px",\\
  "--text-caption--fontFamily": "var(--font1)",\\
  "--text-caption--fontWeight": "normal",\\
  "--text-caption--fontType": "regular",\\
  "--text-caption--fontStyle": "normal",\\
  "--text-caption--fontStretch": "normal",\\
  "--text-caption--lineHeight": "1.35",\\
  "--text-caption--marginLeft": "0px",\\
  "--text-caption--color": "var(--palette-color6)",\\
  "--text-caption--borderBottomStyle": "none",\\
  "--text-caption--textDecoration": "none",\\
  "--text-caption--letterSpacing": "0",\\
  "--text-caption--textTransform": "none",\\
  "--text-caption--stroke": "var(--palette-color2)",\\
  "--text-caption--textAlign": "center",\\
  "--text-caption--justifyContent": "flex-start",\\
  "--text-caption--marginTop": "auto",\\
  "--text-caption--marginBottom": "0",\\
  "--text-caption--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_correct--fontSize--desktop": "24px",\\
  "--text-caption_correct--fontSize--tablet": "24px",\\
  "--text-caption_correct--fontSize--mobile": "24px",\\
  "--text-caption_correct--fontFamily": "var(--font1)",\\
  "--text-caption_correct--fontWeight": "normal",\\
  "--text-caption_correct--fontType": "regular",\\
  "--text-caption_correct--fontStyle": "normal",\\
  "--text-caption_correct--fontStretch": "normal",\\
  "--text-caption_correct--lineHeight": "1.35",\\
  "--text-caption_correct--marginLeft": "0px",\\
  "--text-caption_correct--color": "var(--palette-color6)",\\
  "--text-caption_correct--borderBottomStyle": "none",\\
  "--text-caption_correct--textDecoration": "none",\\
  "--text-caption_correct--letterSpacing": "0",\\
  "--text-caption_correct--textTransform": "none",\\
  "--text-caption_correct--stroke": "var(--palette-color2)",\\
  "--text-caption_correct--textAlign": "center",\\
  "--text-caption_correct--justifyContent": "flex-start",\\
  "--text-caption_correct--marginTop": "auto",\\
  "--text-caption_correct--marginBottom": "0",\\
  "--text-caption_correct--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_correct--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_correct--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_correct--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_incorrect--fontSize--desktop": "24px",\\
  "--text-caption_incorrect--fontSize--tablet": "24px",\\
  "--text-caption_incorrect--fontSize--mobile": "24px",\\
  "--text-caption_incorrect--fontFamily": "var(--font1)",\\
  "--text-caption_incorrect--fontWeight": "normal",\\
  "--text-caption_incorrect--fontType": "regular",\\
  "--text-caption_incorrect--fontStyle": "normal",\\
  "--text-caption_incorrect--fontStretch": "normal",\\
  "--text-caption_incorrect--lineHeight": "1.35",\\
  "--text-caption_incorrect--marginLeft": "0px",\\
  "--text-caption_incorrect--color": "var(--palette-color6)",\\
  "--text-caption_incorrect--borderBottomStyle": "none",\\
  "--text-caption_incorrect--textDecoration": "none",\\
  "--text-caption_incorrect--letterSpacing": "0",\\
  "--text-caption_incorrect--textTransform": "none",\\
  "--text-caption_incorrect--stroke": "var(--palette-color2)",\\
  "--text-caption_incorrect--textAlign": "center",\\
  "--text-caption_incorrect--justifyContent": "flex-start",\\
  "--text-caption_incorrect--marginTop": "auto",\\
  "--text-caption_incorrect--marginBottom": "0",\\
  "--text-caption_incorrect--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_incorrect--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_incorrect--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_incorrect--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_incomplete--fontSize--desktop": "24px",\\
  "--text-caption_incomplete--fontSize--tablet": "24px",\\
  "--text-caption_incomplete--fontSize--mobile": "24px",\\
  "--text-caption_incomplete--fontFamily": "var(--font1)",\\
  "--text-caption_incomplete--fontWeight": "normal",\\
  "--text-caption_incomplete--fontType": "regular",\\
  "--text-caption_incomplete--fontStyle": "normal",\\
  "--text-caption_incomplete--fontStretch": "normal",\\
  "--text-caption_incomplete--lineHeight": "1.35",\\
  "--text-caption_incomplete--marginLeft": "0px",\\
  "--text-caption_incomplete--color": "var(--palette-color6)",\\
  "--text-caption_incomplete--borderBottomStyle": "none",\\
  "--text-caption_incomplete--textDecoration": "none",\\
  "--text-caption_incomplete--letterSpacing": "0",\\
  "--text-caption_incomplete--textTransform": "none",\\
  "--text-caption_incomplete--stroke": "var(--palette-color2)",\\
  "--text-caption_incomplete--textAlign": "center",\\
  "--text-caption_incomplete--justifyContent": "flex-start",\\
  "--text-caption_incomplete--marginTop": "auto",\\
  "--text-caption_incomplete--marginBottom": "0",\\
  "--text-caption_incomplete--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_incomplete--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_incomplete--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_incomplete--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_hint--fontSize--desktop": "24px",\\
  "--text-caption_hint--fontSize--tablet": "24px",\\
  "--text-caption_hint--fontSize--mobile": "24px",\\
  "--text-caption_hint--fontFamily": "var(--font1)",\\
  "--text-caption_hint--fontWeight": "normal",\\
  "--text-caption_hint--fontType": "regular",\\
  "--text-caption_hint--fontStyle": "normal",\\
  "--text-caption_hint--fontStretch": "normal",\\
  "--text-caption_hint--lineHeight": "1.35",\\
  "--text-caption_hint--marginLeft": "0px",\\
  "--text-caption_hint--color": "var(--palette-color6)",\\
  "--text-caption_hint--borderBottomStyle": "none",\\
  "--text-caption_hint--textDecoration": "none",\\
  "--text-caption_hint--letterSpacing": "0",\\
  "--text-caption_hint--textTransform": "none",\\
  "--text-caption_hint--stroke": "var(--palette-color2)",\\
  "--text-caption_hint--textAlign": "center",\\
  "--text-caption_hint--justifyContent": "flex-start",\\
  "--text-caption_hint--marginTop": "auto",\\
  "--text-caption_hint--marginBottom": "0",\\
  "--text-caption_hint--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_hint--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_hint--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_hint--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_retry--fontSize--desktop": "24px",\\
  "--text-caption_retry--fontSize--tablet": "24px",\\
  "--text-caption_retry--fontSize--mobile": "24px",\\
  "--text-caption_retry--fontFamily": "var(--font1)",\\
  "--text-caption_retry--fontWeight": "normal",\\
  "--text-caption_retry--fontType": "regular",\\
  "--text-caption_retry--fontStyle": "normal",\\
  "--text-caption_retry--fontStretch": "normal",\\
  "--text-caption_retry--lineHeight": "1.35",\\
  "--text-caption_retry--marginLeft": "0px",\\
  "--text-caption_retry--color": "var(--palette-color6)",\\
  "--text-caption_retry--borderBottomStyle": "none",\\
  "--text-caption_retry--textDecoration": "none",\\
  "--text-caption_retry--letterSpacing": "0",\\
  "--text-caption_retry--textTransform": "none",\\
  "--text-caption_retry--stroke": "var(--palette-color2)",\\
  "--text-caption_retry--textAlign": "center",\\
  "--text-caption_retry--justifyContent": "flex-start",\\
  "--text-caption_retry--marginTop": "auto",\\
  "--text-caption_retry--marginBottom": "0",\\
  "--text-caption_retry--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_retry--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_retry--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_retry--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_timeout--fontSize--desktop": "24px",\\
  "--text-caption_timeout--fontSize--tablet": "24px",\\
  "--text-caption_timeout--fontSize--mobile": "24px",\\
  "--text-caption_timeout--fontFamily": "var(--font1)",\\
  "--text-caption_timeout--fontWeight": "normal",\\
  "--text-caption_timeout--fontType": "regular",\\
  "--text-caption_timeout--fontStyle": "normal",\\
  "--text-caption_timeout--fontStretch": "normal",\\
  "--text-caption_timeout--lineHeight": "1.35",\\
  "--text-caption_timeout--marginLeft": "0px",\\
  "--text-caption_timeout--color": "var(--palette-color6)",\\
  "--text-caption_timeout--borderBottomStyle": "none",\\
  "--text-caption_timeout--textDecoration": "none",\\
  "--text-caption_timeout--letterSpacing": "0",\\
  "--text-caption_timeout--textTransform": "none",\\
  "--text-caption_timeout--stroke": "var(--palette-color2)",\\
  "--text-caption_timeout--textAlign": "center",\\
  "--text-caption_timeout--justifyContent": "flex-start",\\
  "--text-caption_timeout--marginTop": "auto",\\
  "--text-caption_timeout--marginBottom": "0",\\
  "--text-caption_timeout--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_timeout--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_timeout--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_timeout--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_1--fontSize--desktop": "18px",\\
  "--text-caption_1--fontSize--tablet": "18px",\\
  "--text-caption_1--fontSize--mobile": "16px",\\
  "--text-caption_1--fontFamily": "var(--font2)",\\
  "--text-caption_1--fontWeight": "normal",\\
  "--text-caption_1--fontType": "regular",\\
  "--text-caption_1--fontStyle": "normal",\\
  "--text-caption_1--fontStretch": "normal",\\
  "--text-caption_1--lineHeight": "1.2",\\
  "--text-caption_1--marginLeft": "0px",\\
  "--text-caption_1--color": "#FFFFFF",\\
  "--text-caption_1--borderBottomStyle": "none",\\
  "--text-caption_1--textDecoration": "none",\\
  "--text-caption_1--letterSpacing": "0",\\
  "--text-caption_1--textTransform": "none",\\
  "--text-caption_1--stroke": "#00000000",\\
  "--text-caption_1--textAlign": "left",\\
  "--text-caption_1--justifyContent": "flex-start",\\
  "--text-caption_1--marginTop": "auto",\\
  "--text-caption_1--marginBottom": "0",\\
  "--text-caption_1--defaultTextStroke": "1px #00000000",\\
  "--text-caption_1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_2--fontSize--desktop": "20px",\\
  "--text-caption_2--fontSize--tablet": "20px",\\
  "--text-caption_2--fontSize--mobile": "18px",\\
  "--text-caption_2--fontFamily": "var(--font2)",\\
  "--text-caption_2--fontWeight": "normal",\\
  "--text-caption_2--fontType": "bold",\\
  "--text-caption_2--fontStyle": "normal",\\
  "--text-caption_2--fontStretch": "normal",\\
  "--text-caption_2--lineHeight": "1.2",\\
  "--text-caption_2--marginLeft": "0px",\\
  "--text-caption_2--color": "#FFFFFF",\\
  "--text-caption_2--borderBottomStyle": "none",\\
  "--text-caption_2--textDecoration": "none",\\
  "--text-caption_2--letterSpacing": "0",\\
  "--text-caption_2--textTransform": "none",\\
  "--text-caption_2--stroke": "#00000000",\\
  "--text-caption_2--textAlign": "left",\\
  "--text-caption_2--justifyContent": "flex-start",\\
  "--text-caption_2--marginTop": "auto",\\
  "--text-caption_2--marginBottom": "0",\\
  "--text-caption_2--defaultTextStroke": "1px #00000000",\\
  "--text-caption_2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_3--fontSize--desktop": "24px",\\
  "--text-caption_3--fontSize--tablet": "24px",\\
  "--text-caption_3--fontSize--mobile": "22px",\\
  "--text-caption_3--fontFamily": "var(--font1)",\\
  "--text-caption_3--fontWeight": "normal",\\
  "--text-caption_3--fontType": "italic",\\
  "--text-caption_3--fontStyle": "normal",\\
  "--text-caption_3--fontStretch": "normal",\\
  "--text-caption_3--lineHeight": "1.2",\\
  "--text-caption_3--marginLeft": "0px",\\
  "--text-caption_3--color": "#FFFFFF",\\
  "--text-caption_3--borderBottomStyle": "none",\\
  "--text-caption_3--textDecoration": "none",\\
  "--text-caption_3--letterSpacing": "0",\\
  "--text-caption_3--textTransform": "none",\\
  "--text-caption_3--stroke": "#00000000",\\
  "--text-caption_3--textAlign": "left",\\
  "--text-caption_3--justifyContent": "flex-start",\\
  "--text-caption_3--marginTop": "auto",\\
  "--text-caption_3--marginBottom": "0",\\
  "--text-caption_3--defaultTextStroke": "1px #00000000",\\
  "--text-caption_3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_4--fontSize--desktop": "22px",\\
  "--text-caption_4--fontSize--tablet": "22px",\\
  "--text-caption_4--fontSize--mobile": "20px",\\
  "--text-caption_4--fontFamily": "var(--font2)",\\
  "--text-caption_4--fontWeight": "normal",\\
  "--text-caption_4--fontType": "italic",\\
  "--text-caption_4--fontStyle": "normal",\\
  "--text-caption_4--fontStretch": "normal",\\
  "--text-caption_4--lineHeight": "1.3",\\
  "--text-caption_4--marginLeft": "0px",\\
  "--text-caption_4--color": "#666666",\\
  "--text-caption_4--borderBottomStyle": "none",\\
  "--text-caption_4--textDecoration": "none",\\
  "--text-caption_4--letterSpacing": "0",\\
  "--text-caption_4--textTransform": "none",\\
  "--text-caption_4--stroke": "#00000000",\\
  "--text-caption_4--textAlign": "left",\\
  "--text-caption_4--justifyContent": "flex-start",\\
  "--text-caption_4--marginTop": "auto",\\
  "--text-caption_4--marginBottom": "0",\\
  "--text-caption_4--defaultTextStroke": "1px #00000000",\\
  "--text-caption_4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-comment-box--fontSize--desktop": "20px",\\
  "--text-comment-box--fontSize--tablet": "20px",\\
  "--text-comment-box--fontSize--mobile": "20px",\\
  "--text-comment-box--fontFamily": "var(--font1)",\\
  "--text-comment-box--fontWeight": "normal",\\
  "--text-comment-box--fontType": "regular",\\
  "--text-comment-box--fontStyle": "normal",\\
  "--text-comment-box--fontStretch": "normal",\\
  "--text-comment-box--lineHeight": "1.35",\\
  "--text-comment-box--marginLeft": "0px",\\
  "--text-comment-box--color": "var(--palette-color6)",\\
  "--text-comment-box--borderBottomStyle": "none",\\
  "--text-comment-box--textDecoration": "none",\\
  "--text-comment-box--letterSpacing": "0",\\
  "--text-comment-box--textTransform": "none",\\
  "--text-comment-box--stroke": "var(--palette-color2)",\\
  "--text-comment-box--textAlign": "center",\\
  "--text-comment-box--justifyContent": "flex-start",\\
  "--text-comment-box--marginTop": "auto",\\
  "--text-comment-box--marginBottom": "0",\\
  "--text-comment-box--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-comment-box--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-comment-box--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-comment-box--textShadow": "var(--text-style-unset)",\\
\\
  "--theme_image_default--strokeColor": "var(--palette-color1)",\\
  "--theme_image_default--boxShadowColor": "var(--greyscale3)",\\
\\
  "--theme_image_greyscale--strokeColor": "var(--palette-color1)",\\
  "--theme_image_greyscale--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_greyscale--intensity": 100,\\
\\
  "--theme_image_lighten--strokeColor": "var(--palette-color1)",\\
  "--theme_image_lighten--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_lighten--intensity": 80,\\
\\
  "--theme_image_darken--strokeColor": "var(--palette-color1)",\\
  "--theme_image_darken--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_darken--intensity": 80,\\
\\
  "--theme_image_overlay--strokeColor": "var(--palette-color1)",\\
  "--theme_image_overlay--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_overlay--intensity": 80,\\
  "--theme_image_overlay--primaryFillColor": "var(--palette-color2)",\\
  "--theme_image_overlay--secondaryFillColor": "var(--palette-color1)",\\
\\
  "--theme_image_colorize--strokeColor": "var(--palette-color1)",\\
  "--theme_image_colorize--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_colorize--intensity": 80,\\
  "--theme_image_colorize--primaryFillColor": "var(--palette-color4)",\\
  "--theme_image_colorize--secondaryFillColor": "var(--palette-color1)",\\
\\
\\
  "--button-normal--primaryColor": "var(--palette-color7)",\\
  "--button-normal--borderColor": "var(--palette-color7)",\\
  "--button-normal--shadowColor": "var(--greyscale3)",\\
  "--text-button-normal--color": "var(--palette-color0)",\\
  "--text-button-normal--fontFamily": "var(--font2)",\\
  "--text-button-normal--fontType": "regular",\\
  "--text-button-normal--fontSize--desktop": "16px",\\
  "--text-button-normal--fontSize--tablet": "16px",\\
  "--text-button-normal--fontSize--mobile": "16px",\\
\\
  "--button-selected--primaryColor": "var(--palette-color5)",\\
  "--button-selected--borderColor": "var(--palette-color5)",\\
  "--button-selected--shadowColor": "var(--greyscale3)",\\
  "--text-button-selected--color": "var(--palette-color0)",\\
  "--text-button-selected--fontFamily": "var(--font2)",\\
  "--text-button-selected--fontType": "regular",\\
  "--text-button-selected--fontSize--desktop": "16px",\\
  "--text-button-selected--fontSize--tablet": "16px",\\
  "--text-button-selected--fontSize--mobile": "16px",\\
\\
  "--button-disabled--primaryColor": "var(--palette-color3)",\\
  "--button-disabled--borderColor": "var(--palette-color3)",\\
  "--button-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-button-disabled--color": "var(--palette-color4)",\\
  "--text-button-disabled--fontFamily": "var(--font2)",\\
  "--text-button-disabled--fontType": "regular",\\
  "--text-button-disabled--fontSize--desktop": "16px",\\
  "--text-button-disabled--fontSize--tablet": "16px",\\
  "--text-button-disabled--fontSize--mobile": "16px",\\
\\
  "--button-hover--primaryColor": "#112FA7",\\
  "--button-hover--borderColor": "#112FA7",\\
  "--button-hover--shadowColor": "var(--greyscale3)",\\
  "--text-button-hover--color": "var(--palette-color0)",\\
  "--text-button-hover--fontFamily": "var(--font2)",\\
  "--text-button-hover--fontType": "regular",\\
  "--text-button-hover--fontSize--desktop": "16px",\\
  "--text-button-hover--fontSize--tablet": "16px",\\
  "--text-button-hover--fontSize--mobile": "16px",\\
\\
  "--button-visited--primaryColor": "#112FA780",\\
  "--button-visited--borderColor": "#112FA780",\\
  "--button-visited--shadowColor": "var(--greyscale3)",\\
  "--text-button-visited--color": "var(--palette-color0)",\\
  "--text-button-visited--fontFamily": "var(--font2)",\\
  "--text-button-visited--fontType": "regular",\\
  "--text-button-visited--fontSize--desktop": "16px",\\
  "--text-button-visited--fontSize--tablet": "16px",\\
  "--text-button-visited--fontSize--mobile": "16px",\\
\\
  "--checkbox-normal--primaryColor": "var(--palette-color0)",\\
  "--checkbox-normal--borderColor": "var(--palette-color3)",\\
  "--checkbox-normal--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-normal--color": "var(--palette-color4)",\\
  "--text-checkbox-normal--fontFamily": "var(--font1)",\\
  "--text-checkbox-normal--fontType": "regular",\\
  "--text-checkbox-normal--fontSize--desktop": "22px",\\
  "--text-checkbox-normal--fontSize--tablet": "20px",\\
  "--text-checkbox-normal--fontSize--mobile": "20px",\\
\\
  "--checkbox-selected--primaryColor": "var(--palette-color7)",\\
  "--checkbox-selected--borderColor": "var(--palette-color4)",\\
  "--checkbox-selected--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-selected--color": "var(--palette-color4)",\\
  "--text-checkbox-selected--fontFamily": "var(--font1)",\\
  "--text-checkbox-selected--fontType": "regular",\\
  "--text-checkbox-selected--fontSize--desktop": "22px",\\
  "--text-checkbox-selected--fontSize--tablet": "20px",\\
  "--text-checkbox-selected--fontSize--mobile": "20px",\\
\\
  "--checkbox-disabled-checked--primaryColor": "var(--palette-color3)",\\
  "--checkbox-disabled-checked--borderColor": "var(--palette-color3)",\\
  "--checkbox-disabled-checked--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-disabled-checked--color": "var(--palette-color3)",\\
  "--text-checkbox-disabled-checked--fontFamily": "var(--font1)",\\
  "--text-checkbox-disabled-checked--fontType": "regular",\\
  "--text-checkbox-disabled-checked--fontSize--desktop": "22px",\\
  "--text-checkbox-disabled-checked--fontSize--tablet": "20px",\\
  "--text-checkbox-disabled-checked--fontSize--mobile": "20px",\\
\\
  "--checkbox-hover--primaryColor": "var(--palette-color0)",\\
  "--checkbox-hover--borderColor": "var(--palette-color3)",\\
  "--checkbox-hover--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-hover--color": "var(--palette-color5)",\\
  "--text-checkbox-hover--fontFamily": "var(--font1)",\\
  "--text-checkbox-hover--fontType": "regular",\\
  "--text-checkbox-hover--fontSize--desktop": "22px",\\
  "--text-checkbox-hover--fontSize--tablet": "20px",\\
  "--text-checkbox-hover--fontSize--mobile": "20px",\\
\\
  "--checkbox-disabled-unchecked--primaryColor": "var(--palette-color3)",\\
  "--checkbox-disabled-unchecked--borderColor": "var(--palette-color3)",\\
  "--checkbox-disabled-unchecked--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-disabled-unchecked--color": "var(--palette-color3)",\\
  "--text-checkbox-disabled-unchecked--fontFamily": "var(--font1)",\\
  "--text-checkbox-disabled-unchecked--fontType": "regular",\\
  "--text-checkbox-disabled-unchecked--fontSize--desktop": "22px",\\
  "--text-checkbox-disabled-unchecked--fontSize--tablet": "20px",\\
  "--text-checkbox-disabled-unchecked--fontSize--mobile": "20px",\\
\\
  "--inputfield-normal--primaryColor": "var(--palette-color0)", \\
  "--inputfield-normal--borderColor": "var(--palette-color3)",\\
  "--inputfield-normal--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-normal--color": "var(--palette-color4)",\\
  "--text-inputfield-normal--fontFamily": "var(--font1)",\\
  "--text-inputfield-normal--fontType": "regular",\\
  "--text-inputfield-normal--fontSize--desktop": "18px",\\
  "--text-inputfield-normal--fontSize--tablet": "20px",\\
  "--text-inputfield-normal--fontSize--mobile": "20px",\\
\\
  "--inputfield-active--primaryColor": "var(--palette-color0)",\\
  "--inputfield-active--borderColor": "var(--palette-color7)",\\
  "--inputfield-active--shadowColor": "#var(--greyscale3)",\\
  "--text-inputfield-active--color": "var(--palette-color4)",\\
  "--text-inputfield-active--fontFamily": "var(--font1)",\\
  "--text-inputfield-active--fontType": "regular",\\
  "--text-inputfield-active--fontSize--desktop": "18px",\\
  "--text-inputfield-active--fontSize--tablet": "20px",\\
  "--text-inputfield-active--fontSize--mobile": "20px",\\
\\
  "--inputfield-disabled--primaryColor": "var(--palette-color3)",\\
  "--inputfield-disabled--borderColor": "var(--palette-color3)",\\
  "--inputfield-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-disabled--color": "var(--palette-color1)",\\
  "--text-inputfield-disabled--fontFamily": "var(--font1)",\\
  "--text-inputfield-disabled--fontType": "regular",\\
  "--text-inputfield-disabled--fontSize--desktop": "18px",\\
  "--text-inputfield-disabled--fontSize--tablet": "20px",\\
  "--text-inputfield-disabled--fontSize--mobile": "20px",\\
\\
  "--inputfield-focusLost--primaryColor": "var(--palette-color0)",\\
  "--inputfield-focusLost--borderColor": "var(--palette-color3)",\\
  "--inputfield-focusLost--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-focusLost--color": "var(--palette-color4)",\\
  "--text-inputfield-focusLost--fontFamily": "var(--font1)",\\
  "--text-inputfield-focusLost--fontType": "regular",\\
  "--text-inputfield-focusLost--fontSize--desktop": "18px",\\
  "--text-inputfield-focusLost--fontSize--tablet": "20px",\\
  "--text-inputfield-focusLost--fontSize--mobile": "20px",\\
\\
  "--inputfield-error--primaryColor": "var(--palette-color0)",\\
  "--inputfield-error--borderColor": "var(--error)",\\
  "--inputfield-error--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-error--color": "var(--palette-color4)",\\
  "--text-inputfield-error--fontFamily": "var(--font1)",\\
  "--text-inputfield-error--fontType": "regular",\\
  "--text-inputfield-error--fontSize--desktop": "18px",\\
  "--text-inputfield-error--fontSize--tablet": "20px",\\
  "--text-inputfield-error--fontSize--mobile": "20px",\\
\\
  "--dropdown-normal--primaryColor": "var(--palette-color0)",\\
  "--dropdown-normal--borderColor": "var(--palette-color3)",\\
  "--dropdown-normal--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-normal--color": "var(--palette-color4)",\\
  "--text-dropdown-normal--fontFamily": "var(--font1)",\\
  "--text-dropdown-normal--fontType": "italic",\\
  "--text-dropdown-normal--fontSize--desktop": "18px",\\
  "--text-dropdown-normal--fontSize--tablet": "18px",\\
  "--text-dropdown-normal--fontSize--mobile": "18px",\\
\\
  "--dropdown-selected--primaryColor": "var(--palette-color0)",\\
  "--dropdown-selected--borderColor": "var(--palette-color7)",\\
  "--dropdown-selected--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-selected--color": "var(--palette-color4)",\\
  "--text-dropdown-selected--fontFamily": "var(--font1)",\\
  "--text-dropdown-selected--fontType": "italic",\\
  "--text-dropdown-selected--fontSize--desktop": "18px",\\
  "--text-dropdown-selected--fontSize--tablet": "18px",\\
  "--text-dropdown-selected--fontSize--mobile": "18px",\\
\\
  "--dropdown-disabled--primaryColor": "var(--palette-color3)",\\
  "--dropdown-disabled--borderColor": "var(--palette-color3)",\\
  "--dropdown-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-disabled--color": "var(--palette-color1)",\\
  "--text-dropdown-disabled--fontFamily": "var(--font1)",\\
  "--text-dropdown-disabled--fontType": "italic",\\
  "--text-dropdown-disabled--fontSize--desktop": "18px",\\
  "--text-dropdown-disabled--fontSize--tablet": "18px",\\
  "--text-dropdown-disabled--fontSize--mobile": "18px",\\
\\
  "--dropdown-hover--primaryColor": "var(--palette-color0)",\\
  "--dropdown-hover--borderColor": "var(--palette-color3)",\\
  "--dropdown-hover--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-hover--color": "var(--palette-color4)",\\
  "--text-dropdown-hover--fontFamily": "var(--font1)",\\
  "--text-dropdown-hover--fontType": "italic",\\
  "--text-dropdown-hover--fontSize--desktop": "18px",\\
  "--text-dropdown-hover--fontSize--tablet": "18px",\\
  "--text-dropdown-hover--fontSize--mobile": "18px",\\
\\
  "--radio-normal--primaryColor": "var(--palette-color0)",\\
  "--radio-normal--borderColor": "var(--palette-color3)",\\
  "--radio-normal--shadowColor": "var(--greyscale3)",\\
  "--text-radio-normal--color": "var(--palette-color4)",\\
  "--text-radio-normal--fontFamily": "var(--font1)",\\
  "--text-radio-normal--fontType": "regular",\\
  "--text-radio-normal--fontSize--desktop": "22px",\\
  "--text-radio-normal--fontSize--tablet": "20px",\\
  "--text-radio-normal--fontSize--mobile": "20px",\\
\\
  "--radio-selected--primaryColor": "var(--palette-color0)",\\
  "--radio-selected--borderColor": "var(--palette-color4)",\\
  "--radio-selected--shadowColor": "var(--greyscale3)",\\
  "--text-radio-selected--color": "var(--palette-color4)",\\
  "--text-radio-selected--fontFamily": "var(--font1)",\\
  "--text-radio-selected--fontType": "regular",\\
  "--text-radio-selected--fontSize--desktop": "22px",\\
  "--text-radio-selected--fontSize--tablet": "20px",\\
  "--text-radio-selected--fontSize--mobile": "20px",\\
\\
  "--radio-disabled-checked--primaryColor": "var(--palette-color3)",\\
  "--radio-disabled-checked--borderColor": "var(--palette-color3)",\\
  "--radio-disabled-checked--shadowColor": "var(--greyscale3)",\\
  "--text-radio-disabled-checked--color": "var(--palette-color3)",\\
  "--text-radio-disabled-checked--fontFamily": "var(--font1)",\\
  "--text-radio-disabled-checked--fontType": "regular",\\
  "--text-radio-disabled-checked--fontSize--desktop": "22px",\\
  "--text-radio-disabled-checked--fontSize--tablet": "20px",\\
  "--text-radio-disabled-checked--fontSize--mobile": "20px",\\
\\
  "--radio-hover--primaryColor": "var(--palette-color0)",\\
  "--radio-hover--borderColor": "var(--palette-color3)",\\
  "--radio-hover--shadowColor": "var(--greyscale3)",\\
  "--text-radio-hover--color": "var(--palette-color5)",\\
  "--text-radio-hover--fontFamily": "var(--font1)",\\
  "--text-radio-hover--fontType": "regular",\\
  "--text-radio-hover--fontSize--desktop": "22px",\\
  "--text-radio-hover--fontSize--tablet": "20px",\\
  "--text-radio-hover--fontSize--mobile": "20px",\\
\\
  "--radio-disabled-unchecked--primaryColor": "var(--palette-color3)",\\
  "--radio-disabled-unchecked--borderColor": "var(--palette-color3)",\\
  "--radio-disabled-unchecked--shadowColor": "var(--greyscale3)",\\
  "--text-radio-disabled-unchecked--color": "var(--palette-color3)",\\
  "--text-radio-disabled-unchecked--fontFamily": "var(--font1)",\\
  "--text-radio-disabled-unchecked--fontType": "regular",\\
  "--text-radio-disabled-unchecked--fontSize--desktop": "22px",\\
  "--text-radio-disabled-unchecked--fontSize--tablet": "20px",\\
  "--text-radio-disabled-unchecked--fontSize--mobile": "20px",\\
\\
  "--video_preset-color": "#666666",\\
  "--video_preset-borderColor": "#666666",\\
  \\
  "--clickbox-preset-fill-color": "#3F80E4",\\
\\
  "--drag-object-default-state-fill-color": "255, 255, 255",\\
  "--drag-object-hover-state-fill-color": "250, 250, 250",\\
  "--drag-object-transition-state-fill-color": "250, 250, 250",\\
  "--drag-object-dragOver-state-fill-color": "250, 250, 250",\\
  "--drag-object-dropped-state-fill-color": "255, 255, 255",\\
\\
  "--drag-object-default-state-border-color": "214, 213, 209",\\
  "--drag-object-hover-state-border-color": "214, 213, 209",\\
  "--drag-object-transition-state-border-color": "214, 213, 209",\\
  "--drag-object-dragOver-state-border-color": "230, 132, 80",\\
  "--drag-object-dropped-state-border-color": "214, 213, 209",\\
\\
  "--drop-object-default-state-fill-color": "255, 255, 255",\\
  "--drop-object-hover-state-fill-color": "255, 255, 255",\\
  "--drop-object-dragOver-state-fill-color": "230, 132, 80",\\
  "--drop-object-dropped-state-fill-color": "255, 255, 255",\\
\\
  "--drop-object-default-state-border-color": "42, 49, 62",\\
  "--drop-object-hover-state-border-color": "230, 132, 80",\\
  "--drop-object-dragOver-state-border-color": "230, 132, 80",\\
  "--drop-object-dropped-state-border-color": "42, 49, 62"\\
}',
uic_presets:'{\\
  "cp_button_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 1,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "--button-selected--shadowColor",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-visited--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style": {\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "#707070",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_hover": {\\
    "fill": "#9ec4f3",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--black)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_selected": {\\
    "fill": "var(--palette-color5)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_visited": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_disabled": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_active": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-active--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-active--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-active--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_focusLost": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-focusLost--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-focusLost--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-focusLost--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_error": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-error--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-error--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-error--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 14,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.78\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "video_preset_style": {\\
    "fillEnable": 0,\\
    "strokeEnable": 0,\\
    "shadowEnable": 0,\\
    "fill": "var(--video_preset-color)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--video_preset-border)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_comment_box_shape_1_solid_style": {\\
    "fill": "#F2B807",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clickbox_shape_solid_style": {\\
    "fill": "var(--clickbox-preset-fill-color)",\\
    "fillOpacity": 0.6,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "2, 3",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#333333",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#000000",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#D6D5D1",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clicktoreveal_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#ffffff",\\
    "fillOpacity": 1,\\
    "stroke": "#ffffff",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 3,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color7)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color8)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_blue": {\\
    "fill": "#ADD8E6",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}'
},
project_main:{
from:1,
to:0,
currentFrame:1,
featureFlags:{
isNewWidgetArchitecture:'{"isEnabled":true,"featureData":{}}'
}
,
useResponsive:true,
responsiveType:512,
isResponsiveSim:1,
currentFrame:1,
useWidgetVersion7:false,
isPublishedFromLacuna:false,
slideAudios:'StAd1',
vestr:0,
vim:0,
slides:'Slide388,Slide9961,Slide10078,Slide10115,Slide10232,Slide10269,Slide10313,Slide10350,Slide10394,Slide10511,Slide10628,Slide10745,Slide10862,Slide10906,Slide11023,Slide11140,Slide11177,Slide11221,Slide11338,Slide11455',
slideVideos:['si10306','si10387','si10899','si11214'],
questions:'',
autoplay:false,
preloader:true,
preloaderFileName:'dr/loading.gif',
preloaderPercentage:100,
pprtd:false,
peon:false,
fadeInAtStart:0,
fadeOutAtEnd:0
},
borderProperties:{
hasBorder:false
},
playBarProperties:{
hasPlayBar:true,
jsfile:'playbarScript.js',
cssfile:'playbarStyle.css',
position:3,
layout:3,
showOnHover:false,
overlay:true,
tworow:false,
hasRewind:true,
hasBackward:true,
hasPlay:true,
hasEnterVR:false,
hasSlider:true,
hasForward:true,
hasCC:false,
hasAudioOn:true,
hasExit:true,
hasFastForward:true,
applyColors:false,
alpha:100,
noToolTips:false,
locale:0
},
tocProperties:{
tocProperties:'{"tocConfig":{"labels":{"TITLE":"Table of Content","SLIDE_DETAILS":"SLIDE TITLE","DURATION":"DURATION","CLOSE_BUTTON_LABEL":"Close"},"slideDetails":[{"label":"Blank 1","type":"slide","parentId":null,"id":"Slide388","isVisible":true,"slideVisited":false,"originalId":388,"labelShouldBeInSync":true},{"label":"Simulation slide 1","type":"slide","parentId":null,"id":"Slide9961","isVisible":true,"slideVisited":false,"originalId":9961,"labelShouldBeInSync":true},{"label":"Simulation slide 2","type":"slide","parentId":null,"id":"Slide10078","isVisible":true,"slideVisited":false,"originalId":10078,"labelShouldBeInSync":true},{"label":"Simulation slide 3","type":"slide","parentId":null,"id":"Slide10115","isVisible":true,"slideVisited":false,"originalId":10115,"labelShouldBeInSync":true},{"label":"Simulation slide 4","type":"slide","parentId":null,"id":"Slide10232","isVisible":true,"slideVisited":false,"originalId":10232,"labelShouldBeInSync":true},{"label":"Simulation slide 5","type":"slide","parentId":null,"id":"Slide10269","isVisible":true,"slideVisited":false,"originalId":10269,"labelShouldBeInSync":true},{"label":"Simulation slide 6","type":"slide","parentId":null,"id":"Slide10313","isVisible":true,"slideVisited":false,"originalId":10313,"labelShouldBeInSync":true},{"label":"Simulation slide 7","type":"slide","parentId":null,"id":"Slide10350","isVisible":true,"slideVisited":false,"originalId":10350,"labelShouldBeInSync":true},{"label":"Simulation slide 8","type":"slide","parentId":null,"id":"Slide10394","isVisible":true,"slideVisited":false,"originalId":10394,"labelShouldBeInSync":true},{"label":"Simulation slide 9","type":"slide","parentId":null,"id":"Slide10511","isVisible":true,"slideVisited":false,"originalId":10511,"labelShouldBeInSync":true},{"label":"Simulation slide 10","type":"slide","parentId":null,"id":"Slide10628","isVisible":true,"slideVisited":false,"originalId":10628,"labelShouldBeInSync":true},{"label":"Simulation slide 11","type":"slide","parentId":null,"id":"Slide10745","isVisible":true,"slideVisited":false,"originalId":10745,"labelShouldBeInSync":true},{"label":"Simulation slide 12","type":"slide","parentId":null,"id":"Slide10862","isVisible":true,"slideVisited":false,"originalId":10862,"labelShouldBeInSync":true},{"label":"Simulation slide 13","type":"slide","parentId":null,"id":"Slide10906","isVisible":true,"slideVisited":false,"originalId":10906,"labelShouldBeInSync":true},{"label":"Simulation slide 14","type":"slide","parentId":null,"id":"Slide11023","isVisible":true,"slideVisited":false,"originalId":11023,"labelShouldBeInSync":true},{"label":"Simulation slide 15","type":"slide","parentId":null,"id":"Slide11140","isVisible":true,"slideVisited":false,"originalId":11140,"labelShouldBeInSync":true},{"label":"Simulation slide 16","type":"slide","parentId":null,"id":"Slide11177","isVisible":true,"slideVisited":false,"originalId":11177,"labelShouldBeInSync":true},{"label":"Simulation slide 17","type":"slide","parentId":null,"id":"Slide11221","isVisible":true,"slideVisited":false,"originalId":11221,"labelShouldBeInSync":true},{"label":"Simulation slide 18","type":"slide","parentId":null,"id":"Slide11338","isVisible":true,"slideVisited":false,"originalId":11338,"labelShouldBeInSync":true},{"label":"Simulation slide 19","type":"slide","parentId":null,"id":"Slide11455","isVisible":true,"slideVisited":false,"originalId":11455,"labelShouldBeInSync":true}],"tocGeneratedOnPreviewClick":false,"preserveSlidesOrder":true},"playbarConfig":{"isPlaybarControlsPlayEnabled":true,"isPlaybarControlsNextEnabled":true,"isPlaybarControlsTOCEnabled":true,"isShowPlaybarEnabled":true,"isShowTooltipsEnabled":true,"isPlaybarControlsBackEnabled":true,"isHidePlaybarInQuizEnabled":false,"isPlaybarControlsMuteEnabled":true,"isPlaybarControlsClosedCaptionsEnabled":false}}'
},
trecs:[{
link:388,
text:['""']
}
,{
link:9961,
text:['""']
}
,{
link:10078,
text:['""']
}
,{
link:10115,
text:['""']
}
,{
link:10232,
text:['""']
}
,{
link:10269,
text:['""']
}
,{
link:10313,
text:['""']
}
,{
link:10350,
text:['""']
}
,{
link:10394,
text:['""']
}
,{
link:10511,
text:['""']
}
,{
link:10628,
text:['""']
}
,{
link:10745,
text:['""']
}
,{
link:10862,
text:['""']
}
,{
link:10906,
text:['""']
}
,{
link:11023,
text:['""']
}
,{
link:11140,
text:['""']
}
,{
link:11177,
text:['""']
}
,{
link:11221,
text:['""']
}
,{
link:11338,
text:['""']
}
,{
link:11455,
text:['""']
}
]

,
typekit:{
kit_id:''
},
};
cp.model.projectImages=[
'assets/htmlimages/ThreeD_Close.svg',
'assets/htmlimages/ThreeD_HotspotDefaultGlow.png',
'assets/htmlimages/ThreeD_HotspotGlow.png',
'assets/htmlimages/assessmenthotspotvisited.svg',
'assets/htmlimages/expand_icon.png',
'assets/htmlimages/img_trans.gif',
'assets/htmlimages/placeholder.png'
];
cp.model.data.images=[{
ip:'dr/010112.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010149.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010266.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010302.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010347.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010383.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010428.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010545.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010662.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010779.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010895.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/010940.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/011057.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/011174.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/011210.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/011255.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/011372.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/011489.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/08412.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/08657.jpeg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/09995.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
];
cp.model.videos=[
];
cp.model.slideVideos=[
'vr/Vi10295.mp4',
'vr/Vi10376.mp4',
'vr/Vi10888.mp4',
'vr/Vi11203.mp4'
];
cp.model.tocVideos=[
];
cp.model.audios=[
'ar/StAd0.mp3'
];

cp.initVariables = function(){
cp.cv('CaptivateVersion','12.2.0',1,1000,0);
cp.cv('Date.DateDDMMYY','dd/mm/yyyy',1,15,0);
cp.cv('Date.DateMMDDYY','mm/dd/yyyy',1,15,0);
cp.cv('Date.Day',1,1,15,0);
cp.cv('Date.Hours','hh',1,15,0);
cp.cv('Date.LocaleString','',1,15,0);
cp.cv('Date.Minutes','mm',1,15,0);
cp.cv('Date.Month','mm',1,15,0);
cp.cv('Date.Time','hh:mm:ss',1,15,0);
cp.cv('Date.Today','dd',1,15,0);
cp.cv('Date.Year','yyyy',1,15,0);
cp.cv('Project.AudioLevel',100,1,15,0);
cp.cv('Project.ClosedCaptions',1,1,15,0);
cp.cv('Project.CurrentSlideName','slide',1,15,0);
cp.cv('Project.CurrentSlideNumber',1,1,15,0);
cp.cv('Project.LockTOC',0,1,15,0);
cp.cv('Project.MuteAudio',0,1,15,0);
cp.cv('Project.ShowPlaybar',1,1,15,0);
cp.cv('Project.ShowTOC',0,1,15,0);
cp.cv('Project.SlideCount',1,1,15,0);
cp.cv('Question.AnswerChoice','',1,15,0);
cp.cv('Question.MaxAttempts',0,1,15,0);
cp.cv('Question.NegativePoints',0,1,15,0);
cp.cv('Question.PointsAssigned',0,1,15,0);
cp.cv('Question.PreviousQuestionScore',0,1,15,0);
cp.cv('Quiz.AttemptCount',0,1,15,0);
cp.cv('Quiz.CorrectAnswerCount',0,1,15,0);
cp.cv('Quiz.InReview',0,1,15,0);
cp.cv('Quiz.InScope',0,1,15,0);
cp.cv('Quiz.MaxScore',0,1,1000,0);
cp.cv('Quiz.Pass',0,1,15,0);
cp.cv('Quiz.PassPercentage',80,1,1000,0);
cp.cv('Quiz.PassPoints',0,1,1000,0);
cp.cv('Quiz.PercentageScore',0,1,15,0);
cp.cv('Quiz.QuestionCount',0,1,1000,0);
cp.cv('Quiz.Score',0,1,15,0);
cp.cv('Quiz.UnansweredQuestionCount',0,1,1000,0);
cp.cv('cpInfoHasPlaybar',1,1,1000,0);
cp.cv('cpInfoSlidesInProject',20,1,1000,0);
cp.cv('cpLockTOC',0,1,1000,0);
cp.cv('cpQuizInfoPreTestTotalQuestions',0,1,1000,0);
cp.cv('cpQuizInfoTotalQuizPoints',0,1,1000,0);
cp.cv('cpInfoPrevFrame',0,1,15,0);
cp.cv('LMS.CourseName','',0,15,0);
cp.cv('LMS.LearnerID','',0,15,0);
cp.cv('LMS.LearnerName','',0,15,0);
};cp.ReportingVariables="LMS.CourseName,LMS.LearnerID,LMS.LearnerName,";
};cp.sbw=0;cp.useg=0;cp.geo=0;cp.pg=0;cp.win8=0;cp.autoGrow=1;cp.fluidFont=1;
